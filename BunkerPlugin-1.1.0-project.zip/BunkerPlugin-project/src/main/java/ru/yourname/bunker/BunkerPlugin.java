package ru.yourname.bunker;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.Map;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.Configuration;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.InventoryHolder;
import ru.yourname.zombies.ZombieModule;

/** Главный класс плагина. Собирает менеджеры, команды, слушателей. */
public final class BunkerPlugin extends org.bukkit.plugin.java.JavaPlugin implements Listener {

    private FileConfiguration messages;
    private FileConfiguration materials;
    private BunkerCommand bunkerCommand;
    private BunkerManager bunkerManager;
    private ChunkClaimManager claimManager;
    private ExpansionManager expansionManager;
    private OxygenService oxygenService;
    private ZombieModule zombieModule;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        createSchematicsFolder();
        loadMessages();
        loadMaterials();

        bunkerManager = new BunkerManager(this);
        bunkerManager.load();
        claimManager = new ChunkClaimManager(this);
        claimManager.load();

        bunkerCommand = new BunkerCommand(this);
        if (getCommand("bunker") != null) {
            getCommand("bunker").setExecutor(bunkerCommand);
            getCommand("bunker").setTabCompleter(bunkerCommand);
        }
        ControlPanelCommand controlPanel = new ControlPanelCommand(this);
        if (getCommand("controlpanel") != null) {
            getCommand("controlpanel").setExecutor(controlPanel);
            getCommand("controlpanel").setTabCompleter(controlPanel);
        }

        getServer().getPluginManager().registerEvents(new BunkerProtectionListener(this), this);
        getServer().getPluginManager().registerEvents(this, this);

        expansionManager = new ExpansionManager(this);
        if (getConfig().getBoolean("expansion.enabled", true)) {
            getServer().getPluginManager().registerEvents(expansionManager, this);
            expansionManager.start();
        }

        oxygenService = new OxygenService(this);
        oxygenService.start();

        zombieModule = new ZombieModule(this);
        zombieModule.enable();

        registerPlaceholders();
        getLogger().info("BunkerPlugin enabled");
    }

    @Override
    public void onDisable() {
        if (bunkerCommand != null) bunkerCommand.cancelActiveBuilds();
        if (oxygenService != null) oxygenService.stop();
        if (zombieModule != null) zombieModule.disable();
        if (expansionManager != null) expansionManager.stop();
        if (bunkerManager != null) bunkerManager.saveOxygenState();
        if (claimManager != null) claimManager.save();
        getLogger().info("BunkerPlugin disabled");
    }

    /** Полная перезагрузка конфигов и сервисов (/bunker reload). */
    public void reloadAll() {
        reloadConfig();
        loadMessages();
        loadMaterials();
        createSchematicsFolder();
        if (bunkerManager != null) {
            bunkerManager.saveOxygenState();
            bunkerManager.reload();
        }
        if (claimManager != null) claimManager.load();
        if (expansionManager != null) expansionManager.start();
        if (oxygenService != null) oxygenService.start();
        if (zombieModule != null) zombieModule.reload();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        if (oxygenService != null) oxygenService.handleQuit(event.getPlayer().getUniqueId());
    }

    /** Роутинг кликов по GUI-меню (по InventoryHolder). */
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (holder instanceof ControlPanelMenu) {
            ((ControlPanelMenu) holder).onClick(event);
        } else if (holder instanceof ExpansionMenu) {
            ((ExpansionMenu) holder).onClick(event);
        }
    }

    public FileConfiguration getMessages() { return messages; }
    public FileConfiguration getMaterials() { return materials; }
    public BunkerManager getBunkerManager() { return bunkerManager; }
    public ChunkClaimManager getClaimManager() { return claimManager; }
    public ExpansionManager getExpansionManager() { return expansionManager; }
    public ZombieModule getZombieModule() { return zombieModule; }
    public OxygenService getOxygenService() { return oxygenService; }

    public boolean isPlayerBuilding(java.util.UUID uuid) {
        return bunkerCommand != null && bunkerCommand.isBuilding(uuid);
    }

    public File getSchematicsFolder() {
        return new File(getDataFolder(), "schematics");
    }

    private void registerPlaceholders() {
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") == null) {
            getLogger().info("PlaceholderAPI not found, placeholders disabled");
            return;
        }
        try {
            new BunkerPlaceholders(this).register();
            getLogger().info("PlaceholderAPI expansion registered");
        } catch (Throwable e) {
            getLogger().warning("Could not register PlaceholderAPI expansion: " + e.getMessage());
        }
    }

    private void createSchematicsFolder() {
        File folder = getSchematicsFolder();
        if (!folder.exists() && !folder.mkdirs()) {
            getLogger().warning("Could not create schematics folder");
        }
    }

    private void loadMessages() {
        if (!getDataFolder().exists() && !getDataFolder().mkdirs()) {
            getLogger().warning("Could not create plugin data folder");
        }
        File file = new File(getDataFolder(), "messages.yml");
        if (!file.exists()) saveResource("messages.yml", false);
        messages = YamlConfiguration.loadConfiguration(file);
        InputStream defaults = getResource("messages.yml");
        if (defaults != null) {
            YamlConfiguration bundled = YamlConfiguration.loadConfiguration((Reader) new InputStreamReader(defaults, StandardCharsets.UTF_8));
            messages.setDefaults((Configuration) bundled);
        }
    }

    private void loadMaterials() {
        if (!getDataFolder().exists() && !getDataFolder().mkdirs()) {
            getLogger().warning("Could not create plugin data folder");
        }
        File file = new File(getDataFolder(), "materials.yml");
        if (!file.exists()) saveResource("materials.yml", false);
        materials = YamlConfiguration.loadConfiguration(file);
        InputStream defaults = getResource("materials.yml");
        if (defaults != null) {
            YamlConfiguration bundled = YamlConfiguration.loadConfiguration((Reader) new InputStreamReader(defaults, StandardCharsets.UTF_8));
            materials.setDefaults((Configuration) bundled);
        }
    }

    /** Отправить сообщение из messages.yml с {плейсхолдерами} и префиксом. */
    public void sendMessage(CommandSender sender, String key) {
        sendMessage(sender, key, java.util.Collections.emptyMap());
    }

    public void sendMessage(CommandSender sender, String key, Map placeholders) {
        String prefix = color(messages.getString("prefix", ""));
        String message = messages.getString(key, key);
        Iterator it = placeholders.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            message = message.replace("{" + entry.getKey() + "}", String.valueOf(entry.getValue()));
        }
        sender.sendMessage(color(prefix + message));
    }

    private String color(String s) {
        return s == null ? "" : ChatColor.translateAlternateColorCodes('&', s);
    }
}

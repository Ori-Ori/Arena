package ru.yourname.bunker;

import java.util.Iterator;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;

/** Защита бункера: ломание/установка блоков, взрывы, поршни. */
public final class BunkerProtectionListener implements Listener {

    private final BunkerPlugin plugin;

    public BunkerProtectionListener(BunkerPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        if (canBypass(event.getPlayer())) return;
        if (plugin.getClaimManager() != null && plugin.getClaimManager().isProtectedBlockFor(event.getPlayer(), event.getBlock())) {
            event.setCancelled(true);
            plugin.sendMessage(event.getPlayer(), "not-bunker-member");
            return;
        }
        if (plugin.getBunkerManager().isProtectedShell(event.getBlock())) {
            event.setCancelled(true);
            plugin.sendMessage(event.getPlayer(), "wall-break-denied");
        }
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        if (canBypass(event.getPlayer())) return;
        if (plugin.getClaimManager() != null && plugin.getClaimManager().isProtectedBlockFor(event.getPlayer(), event.getBlock())) {
            event.setCancelled(true);
            plugin.sendMessage(event.getPlayer(), "not-bunker-member");
            return;
        }
        if (!plugin.getConfig().getBoolean("protection.block-shell-placement", true)) return;
        if (plugin.getBunkerManager().isProtectedShell(event.getBlock())) {
            event.setCancelled(true);
            plugin.sendMessage(event.getPlayer(), "wall-place-denied");
        }
    }

    @EventHandler
    public void onEntityExplode(EntityExplodeEvent event) {
        filterProtectedBlocks(event.blockList());
    }

    @EventHandler
    public void onBlockExplode(BlockExplodeEvent event) {
        filterProtectedBlocks(event.blockList());
    }

    @EventHandler
    public void onPistonExtend(BlockPistonExtendEvent event) {
        BlockFace direction = event.getDirection();
        Iterator it = event.getBlocks().iterator();
        while (it.hasNext()) {
            Block block = (Block) it.next();
            Block target = block.getRelative(direction);
            if (isProtected(block) || isProtected(target)) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onPistonRetract(BlockPistonRetractEvent event) {
        BlockFace direction = event.getDirection().getOppositeFace();
        Iterator it = event.getBlocks().iterator();
        while (it.hasNext()) {
            Block block = (Block) it.next();
            Block target = block.getRelative(direction);
            if (isProtected(block) || isProtected(target)) {
                event.setCancelled(true);
                return;
            }
        }
    }

    /** Убрать защищённые блоки из списка взрыва. */
    private void filterProtectedBlocks(Iterable blocks) {
        Iterator it = blocks.iterator();
        while (it.hasNext()) {
            Block block = (Block) it.next();
            if (isProtected(block)) it.remove();
        }
    }

    private boolean isProtected(Block block) {
        return plugin.getBunkerManager().isProtectedShell(block);
    }

    private boolean canBypass(Player player) {
        return player.hasPermission("bunker.protection.bypass");
    }
}

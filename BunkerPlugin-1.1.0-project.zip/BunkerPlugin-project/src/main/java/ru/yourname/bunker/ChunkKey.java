package ru.yourname.bunker;

import java.util.Objects;
import org.bukkit.World;

/** Ключ чанка: мир + координаты чанка. Используется как идентификатор купленных чанков. */
public final class ChunkKey {

    private final String worldName;
    private final int chunkX;
    private final int chunkZ;

    public ChunkKey(String worldName, int chunkX, int chunkZ) {
        this.worldName = worldName;
        this.chunkX = chunkX;
        this.chunkZ = chunkZ;
    }

    public static ChunkKey of(World world, int chunkX, int chunkZ) {
        Objects.requireNonNull(world, "world");
        return new ChunkKey(world.getName(), chunkX, chunkZ);
    }

    public boolean sameWorld(String world) {
        return worldName != null && worldName.equalsIgnoreCase(world);
    }

    /** Сериализация для хранения в yml: "x, z". */
    public String toDataString() {
        return chunkX + ", " + chunkZ;
    }

    /** Обратное преобразование. world — мир клейма (не хранится в самой строке). */
    public static ChunkKey fromDataString(String worldName, String data) {
        if (data == null) return null;
        String[] parts = data.split(",");
        if (parts.length != 2) return null;
        try {
            return new ChunkKey(worldName, Integer.parseInt(parts[0].trim()), Integer.parseInt(parts[1].trim()));
        } catch (NumberFormatException ignored) {
            return null;
        }
    }

    public String worldName() { return worldName; }
    public int chunkX() { return chunkX; }
    public int chunkZ() { return chunkZ; }

    @Override
    public String toString() {
        return worldName + " " + chunkX + ", " + chunkZ;
    }

    @Override
    public int hashCode() {
        int result = worldName != null ? worldName.toLowerCase().hashCode() : 0;
        result = 31 * result + chunkX;
        result = 31 * result + chunkZ;
        return result;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ChunkKey)) return false;
        ChunkKey that = (ChunkKey) o;
        return chunkX == that.chunkX && chunkZ == that.chunkZ && sameWorld(that.worldName);
    }
}

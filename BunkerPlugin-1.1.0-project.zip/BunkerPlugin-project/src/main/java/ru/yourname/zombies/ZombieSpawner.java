package ru.yourname.zombies;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Biome;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;

/** Спавн зомби вокруг игроков: лимиты, дистанции, биомы, вне поля зрения. */
final class ZombieSpawner {

    private final ZombieModule module;
    private final Map biomeTypes = new HashMap(); // Map<String biome, EntityType>
    private int tickCounter;

    ZombieSpawner(ZombieModule module) {
        this.module = module;
        loadBiomes();
    }

    void reload() {
        loadBiomes();
    }

    private void loadBiomes() {
        biomeTypes.clear();
        setDefaultBiomes();
        org.bukkit.configuration.ConfigurationSection section = module.config().raw().getConfigurationSection("biomes");
        if (section == null) return;
        Iterator it = section.getKeys(false).iterator();
        while (it.hasNext()) {
            String key = (String) it.next();
            String value = section.getString(key, "");
            EntityType type = parseEntityType(value);
            if (type != null && isZombieType(type)) biomeTypes.put(key.toLowerCase(Locale.ROOT), type);
        }
    }

    private static EntityType parseEntityType(String name) {
        if (name == null) return null;
        try {
            return EntityType.valueOf(name.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    int tickCounter() { return tickCounter; }

    void bumpTick() { tickCounter++; }

    void tick() {
        int interval = Math.max(1, module.config().spawnIntervalSeconds());
        if (tickCounter % interval != 0) return;
        spawnAroundPlayers();
    }

    private void spawnAroundPlayers() {
        ZombieConfig config = module.config();
        int globalLimit = config.spawnGlobalLimit();
        int perPlayerLimit = config.spawnPerPlayerLimit();
        int tries = config.spawnTriesPerPlayer();
        int minDistance = config.spawnMinDistance();
        int maxDistance = config.spawnMaxDistance();
        boolean daySpawn = config.spawnDay();
        boolean onlySurface = config.spawnOnlySurfacePlayers();
        boolean avoidSight = config.spawnAvoidLineOfSight();

        if (module.countTrackedZombies() >= globalLimit) return;
        Iterator it = Bukkit.getOnlinePlayers().iterator();
        while (it.hasNext()) {
            Player player = (Player) it.next();
            if (module.countTrackedZombies() >= globalLimit) return;
            PlayerStealth stealth = module.stealth(player.getUniqueId());
            if (stealth != null && stealth.newbieProtectionLeft() > 0) continue;      // newbie-защита
            if (onlySurface && !module.isSurfacePlayer(player)) continue;             // внутри бункера не спавним
            if (!daySpawn && module.isDay(player.getWorld())) continue;
            int nearby = module.countTrackedZombiesNear(player.getLocation(), maxDistance + 12);
            for (int attempt = 0; attempt < tries && nearby < perPlayerLimit; attempt++) {
                Location loc = findSpawnLocation(player, minDistance, maxDistance, avoidSight);
                Zombie zombie = spawnZombie(loc, entityTypeForBiome(loc));
                if (zombie != null) nearby++;
            }
        }
    }

    /** Кольцо min..max вокруг игрока: на твёрдый блок, не в бункере, вне поля зрения. */
    private Location findSpawnLocation(Player player, int minDistance, int maxDistance, boolean avoidSight) {
        if (player == null) return null;
        World world = player.getWorld();
        ThreadLocalRandom random = ThreadLocalRandom.current();
        for (int attempt = 0; attempt < 10; attempt++) {
            double angle = random.nextDouble(0.0, Math.PI * 2);
            int distance = random.nextInt(minDistance, maxDistance + 1);
            int x = player.getLocation().getBlockX() + (int) Math.round(Math.cos(angle) * distance);
            int z = player.getLocation().getBlockZ() + (int) Math.round(Math.sin(angle) * distance);
            int y = world.getHighestBlockYAt(x, z) + 1;
            Location loc = new Location(world, x + 0.5, y, z + 0.5);
            if (!world.getBlockAt(x, y - 1, z).getType().isSolid()) continue;
            if (module.getPlugin().getBunkerManager().getBunkerAt(loc) != null) continue;
            if (avoidSight && ZombiePerception.locationVisible(player, loc, maxDistance)) continue;
            return loc;
        }
        return null;
    }

    private Zombie spawnZombie(Location loc, EntityType type) {
        if (loc == null) return null;
        if (!isZombieType(type)) type = EntityType.ZOMBIE;
        Entity entity;
        try {
            entity = loc.getWorld().spawnEntity(loc, type);
        } catch (IllegalArgumentException e) {
            return null;
        }
        if (!(entity instanceof Zombie)) {
            entity.remove();
            return null;
        }
        Zombie zombie = (Zombie) entity;
        module.registerZombie(zombie);
        return zombie;
    }

    /** Тип зомби по биому (PLAINS->ZOMBIE, DESERT->HUSK, OCEAN->DROWNED). */
    private EntityType entityTypeForBiome(Location loc) {
        String biome = resolveBiomeKey(loc);
        EntityType type = (EntityType) biomeTypes.get(biome);
        if (type != null) return type;
        if (biome.contains("desert")) return orDefault((EntityType) biomeTypes.get("desert"), EntityType.HUSK);
        if (biome.contains("ocean")) return orDefault((EntityType) biomeTypes.get("ocean"), EntityType.DROWNED);
        if (biome.contains("forest")) return orDefault((EntityType) biomeTypes.get("forest"), EntityType.ZOMBIE);
        if (biome.contains("plains")) return orDefault((EntityType) biomeTypes.get("plains"), EntityType.ZOMBIE);
        return EntityType.ZOMBIE;
    }

    private String resolveBiomeKey(Location loc) {
        if (loc == null || loc.getWorld() == null) return "unknown";
        try {
            Biome biome = loc.getWorld().getBiome(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
            return biome == null ? "unknown" : biome.toString().toLowerCase(Locale.ROOT).trim();
        } catch (Throwable t) {
            return "unknown";
        }
    }

    private void setDefaultBiomes() {
        biomeTypes.putIfAbsent("plains", EntityType.ZOMBIE);
        biomeTypes.putIfAbsent("desert", EntityType.HUSK);
        biomeTypes.putIfAbsent("ocean", EntityType.DROWNED);
        biomeTypes.putIfAbsent("forest", EntityType.ZOMBIE);
    }

    private static EntityType orDefault(EntityType type, EntityType fallback) {
        return type != null ? type : fallback;
    }

    private static boolean isZombieType(EntityType type) {
        return type == EntityType.ZOMBIE || type == EntityType.HUSK || type == EntityType.DROWNED
                || type == EntityType.ZOMBIE_VILLAGER || type == EntityType.ZOMBIFIED_PIGLIN;
    }
}

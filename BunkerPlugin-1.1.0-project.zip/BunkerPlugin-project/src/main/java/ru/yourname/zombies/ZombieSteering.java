package ru.yourname.zombies;

import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.Location;
import org.bukkit.entity.Zombie;
import org.bukkit.util.Vector;

/** Ручное управление движением зомби (поверх ванильного pathfinder). */
final class ZombieSteering {

    private ZombieSteering() {
    }

    /** Двигаться к точке со скоростью speed (0..1). */
    public static void moveTowards(Zombie zombie, Location target, double speed) {
        if (zombie == null || target == null || !sameWorld(zombie.getLocation(), target)) return;
        Location current = zombie.getLocation();
        Vector direction = target.clone().subtract(current).toVector();
        direction.setY(0);
        if (direction.length() < 1.4) {
            stop(zombie);
            return;
        }
        Vector normalized = direction.clone().normalize();
        Vector velocity = zombie.getVelocity().multiply(0.1).add(normalized.multiply(speed).multiply(0.6));
        velocity.setY(zombie.getVelocity().getY());
        zombie.setVelocity(velocity);
        face(zombie, normalized);
    }

    /** Убегать от точки (с лёгким боковым уклонением у каждого зомби). */
    public static void fleeFrom(Zombie zombie, Location from, double speed) {
        if (zombie == null || from == null || !sameWorld(zombie.getLocation(), from)) return;
        Vector away = zombie.getLocation().toVector().subtract(from.toVector());
        away.setY(0);
        if (away.lengthSquared() < 0.0001) {
            double angle = ThreadLocalRandom.current().nextDouble(0.0, Math.PI * 2);
            away = new Vector(Math.cos(angle), 0.0, Math.sin(angle));
        }
        away.normalize();
        Vector side = new Vector(-away.getZ(), 0.0, away.getX()).normalize();
        double sideFactor = ((zombie.getUniqueId().hashCode() & 1) != 0) ? -1.0 : 1.0;
        Vector velocity = away.multiply(speed).add(side.multiply(0.08 * sideFactor));
        Vector result = zombie.getVelocity().multiply(0.1).add(velocity.multiply(0.6));
        result.setY(zombie.getVelocity().getY());
        zombie.setVelocity(result);
        face(zombie, away.clone().normalize());
    }

    public static void stop(Zombie zombie) {
        if (zombie == null) return;
        Vector velocity = zombie.getVelocity();
        velocity.setX(0.0);
        velocity.setZ(0.0);
        zombie.setVelocity(velocity);
    }

    public static void face(Zombie zombie, Vector direction) {
        if (zombie == null || direction == null || direction.lengthSquared() < 0.0001) return;
        Vector flat = direction.clone();
        flat.setY(0);
        Location loc = zombie.getLocation();
        if (flat.lengthSquared() < 0.0001) return;
        zombie.setRotation((float) Math.toDegrees(Math.atan2(-flat.getX(), flat.getZ())), loc.getPitch());
    }

    private static boolean sameWorld(Location a, Location b) {
        return a != null && b != null && a.getWorld() != null && a.getWorld().equals(b.getWorld());
    }
}

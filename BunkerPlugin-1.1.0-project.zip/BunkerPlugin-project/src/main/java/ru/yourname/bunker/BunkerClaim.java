package ru.yourname.bunker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/** Тим-клейм бункера: глава, заместители, участники, купленные чанки, приглашения и заявки. */
public final class BunkerClaim {

    /** Приглашение игрока в бункер. */
    public static final class Invite {
        private final UUID targetId;
        private final long createdAt;
        public Invite(UUID targetId, long createdAt) { this.targetId = targetId; this.createdAt = createdAt; }
        public UUID targetId() { return targetId; }
        public long createdAt() { return createdAt; }
        @Override public String toString() { return "Invite[" + targetId + ", " + createdAt + "]"; }
        @Override public int hashCode() { return Objects.hash(new Object[]{targetId, Long.valueOf(createdAt)}); }
        @Override public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Invite)) return false;
            Invite that = (Invite) o;
            return createdAt == that.createdAt && targetId.equals(that.targetId);
        }
    }

    /** Запрос игрока на вступление. */
    public static final class JoinRequest {
        private final UUID playerId;
        private final long createdAt;
        public JoinRequest(UUID playerId, long createdAt) { this.playerId = playerId; this.createdAt = createdAt; }
        public UUID playerId() { return playerId; }
        public long createdAt() { return createdAt; }
        @Override public String toString() { return "JoinRequest[" + playerId + ", " + createdAt + "]"; }
        @Override public int hashCode() { return Objects.hash(new Object[]{playerId, Long.valueOf(createdAt)}); }
        @Override public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof JoinRequest)) return false;
            JoinRequest that = (JoinRequest) o;
            return createdAt == that.createdAt && playerId.equals(that.playerId);
        }
    }

    private final UUID bunkerId;
    private final String worldName;
    private final int centerChunkX;
    private final int centerChunkZ;
    private final UUID owner;                       // глава
    private final Set deputies = new HashSet();     // Set<UUID>
    private final Set members = new HashSet();      // Set<UUID>
    private final Set ownedChunks = new HashSet();  // Set<ChunkKey>
    private final List invites = new ArrayList();   // List<Invite>
    private final List requests = new ArrayList();  // List<JoinRequest>

    public BunkerClaim(UUID bunkerId, String worldName, int centerChunkX, int centerChunkZ, UUID owner) {
        this.bunkerId = bunkerId;
        this.worldName = worldName;
        this.centerChunkX = centerChunkX;
        this.centerChunkZ = centerChunkZ;
        this.owner = owner;
        this.ownedChunks.add(new ChunkKey(worldName, centerChunkX, centerChunkZ));
    }

    public UUID bunkerId() { return bunkerId; }
    public String worldName() { return worldName; }
    public int centerChunkX() { return centerChunkX; }
    public int centerChunkZ() { return centerChunkZ; }
    public UUID owner() { return owner; }
    public Set deputies() { return Collections.unmodifiableSet(deputies); }
    public Set members() { return Collections.unmodifiableSet(members); }
    public Set ownedChunks() { return Collections.unmodifiableSet(ownedChunks); }
    public List invites() { return Collections.unmodifiableList(invites); }
    public List requests() { return Collections.unmodifiableList(requests); }

    /** Чанк сетки по смещению от центра (-1..1). */
    public ChunkKey chunkAt(int dx, int dz) {
        return new ChunkKey(worldName, centerChunkX + dx, centerChunkZ + dz);
    }

    /** Все 9 чанков сетки 3x3. */
    public List gridChunks() {
        List out = new ArrayList(9);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                out.add(chunkAt(dx, dz));
            }
        }
        return out;
    }

    public boolean isLeader(UUID uuid) { return owner.equals(uuid); }

    public boolean isDeputy(UUID uuid) { return deputies.contains(uuid); }

    /** Управлять бункером может глава или заместитель. */
    public boolean canManage(UUID uuid) { return isLeader(uuid) || isDeputy(uuid); }

    /** Участник = глава, заместитель или рядовой член. */
    public boolean isMember(UUID uuid) {
        return owner.equals(uuid) || deputies.contains(uuid) || members.contains(uuid);
    }

    public boolean isChunkOwned(ChunkKey key) { return ownedChunks.contains(key); }

    public void addOwnedChunk(ChunkKey key) { ownedChunks.add(key); }

    public void addMember(UUID uuid) {
        if (uuid != null && !owner.equals(uuid)) members.add(uuid);
    }

    public void removeMember(UUID uuid) {
        members.remove(uuid);
        deputies.remove(uuid);
    }

    public void addDeputy(UUID uuid) {
        if (uuid != null && !owner.equals(uuid)) deputies.add(uuid);
    }

    public void removeDeputy(UUID uuid) { deputies.remove(uuid); }

    public Optional findInvite(UUID uuid) {
        Iterator it = invites.iterator();
        while (it.hasNext()) {
            Invite invite = (Invite) it.next();
            if (invite.targetId().equals(uuid)) return Optional.of(invite);
        }
        return Optional.empty();
    }

    public void invite(UUID uuid) {
        if (!findInvite(uuid).isPresent()) {
            invites.add(new Invite(uuid, System.currentTimeMillis()));
        }
    }

    public void acceptInvite(UUID uuid) {
        Iterator inviteIt = invites.iterator();
        while (inviteIt.hasNext()) {
            if (((Invite) inviteIt.next()).targetId().equals(uuid)) inviteIt.remove();
        }
        addMember(uuid);
    }

    public void denyInvite(UUID uuid) {
        Iterator inviteIt = invites.iterator();
        while (inviteIt.hasNext()) {
            if (((Invite) inviteIt.next()).targetId().equals(uuid)) inviteIt.remove();
        }
    }

    public Optional findRequest(UUID uuid) {
        Iterator it = requests.iterator();
        while (it.hasNext()) {
            JoinRequest request = (JoinRequest) it.next();
            if (request.playerId().equals(uuid)) return Optional.of(request);
        }
        return Optional.empty();
    }

    public void requestJoin(UUID uuid) {
        if (!findRequest(uuid).isPresent()) {
            requests.add(new JoinRequest(uuid, System.currentTimeMillis()));
        }
    }

    public void acceptRequest(UUID uuid) {
        Iterator requestIt = requests.iterator();
        while (requestIt.hasNext()) {
            if (((JoinRequest) requestIt.next()).playerId().equals(uuid)) requestIt.remove();
        }
        addMember(uuid);
    }

    public void denyRequest(UUID uuid) {
        Iterator requestIt = requests.iterator();
        while (requestIt.hasNext()) {
            if (((JoinRequest) requestIt.next()).playerId().equals(uuid)) requestIt.remove();
        }
    }

    /** Глава + заместители (для уведомлений). */
    public Set leadersAndDeputies() {
        Set out = new HashSet();
        out.add(owner);
        out.addAll(deputies);
        return out;
    }
}

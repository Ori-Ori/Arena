package ru.yourname.bunker;

import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;

/** PlaceholderAPI: %bunker_<param>%. */
public final class BunkerPlaceholders extends PlaceholderExpansion {

    private final BunkerPlugin plugin;

    public BunkerPlaceholders(BunkerPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getIdentifier() {
        return "bunker";
    }

    @Override
    public String getAuthor() {
        return "BunkerPlugin";
    }

    @Override
    public String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, String param) {
        if (player == null || !player.isOnline()) return "";
        Player online = player.getPlayer();
        if (online == null) return "";
        BunkerManager manager = plugin.getBunkerManager();
        OxygenService oxygen = plugin.getOxygenService();
        if (manager == null || oxygen == null) return "";

        ProtectedBunker bunker = manager.getBunkerAt(online.getLocation());
        ProtectedBunker zone = manager.getOxygenZoneAt(online.getLocation());
        ProtectedBunker any = zone != null ? zone : bunker;

        String key = param.toLowerCase(java.util.Locale.ROOT);
        if (key.equals("oxygen_time")) return any != null ? OxygenService.formatTime(any.oxygenSeconds()) : "--:--";
        if (key.equals("oxygen_seconds")) return any != null ? String.valueOf(any.oxygenSeconds()) : "0";
        if (key.equals("oxygen_max_time")) return any != null ? OxygenService.formatTime(any.maxOxygenSeconds()) : "--:--";
        if (key.equals("oxygen_max_seconds")) return any != null ? String.valueOf(any.maxOxygenSeconds()) : "0";
        if (key.equals("oxygen_percent")) {
            if (any == null || any.maxOxygenSeconds() <= 0) return "0";
            return String.valueOf(Math.round(100f * (float) any.oxygenSeconds() / (float) any.maxOxygenSeconds()));
        }
        if (key.equals("oxygen_has")) return any != null && any.hasOxygen() ? "yes" : "no";
        if (key.equals("oxygen_status")) {
            if (any == null) return "Вне бункера";
            return any.hasOxygen() ? "Кислород есть" : "Кислорода нет";
        }
        if (key.equals("in_bunker")) return bunker != null ? "yes" : "no";
        if (key.equals("in_oxygen_zone")) return zone != null ? "yes" : "no";
        if (key.equals("breath_time")) return OxygenService.formatTime(oxygen.getBreathSeconds(online));
        if (key.equals("breath_seconds")) return String.valueOf(oxygen.getBreathSeconds(online));
        if (key.equals("breath_percent")) {
            int max = Math.max(1, oxygen.getMaxBreathSeconds());
            return String.valueOf(Math.round(100f * (float) oxygen.getBreathSeconds(online) / (float) max));
        }
        return null;
    }
}

package ru.yourname.bunker;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.World;

/** Реестр построенных бункеров + сохранение в bunkers.yml. */
public final class BunkerManager {

    private final BunkerPlugin plugin;
    private final Map bunkers = new LinkedHashMap(); // Map<String id, ProtectedBunker>
    private File file;
    private FileConfiguration config;

    public BunkerManager(BunkerPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        if (!plugin.getDataFolder().exists() && !plugin.getDataFolder().mkdirs()) {
            plugin.getLogger().warning("Could not create plugin data folder");
        }
        file = new File(plugin.getDataFolder(), "bunkers.yml");
        if (!file.exists()) {
            plugin.saveResource("bunkers.yml", false);
        }
        config = YamlConfiguration.loadConfiguration(file);
        bunkers.clear();
        ConfigurationSection section = config.getConfigurationSection("bunkers");
        if (section == null) return;
        Iterator it = section.getKeys(false).iterator();
        while (it.hasNext()) {
            String id = (String) it.next();
            String world = config.getString("bunkers." + id + ".world", "");
            if (world == null || world.trim().isEmpty()) continue;
            Set protectedBlocks = parseEncodedBlocks(config.getStringList("bunkers." + id + ".protected-blocks"));
            Set expansionAnchors = parseEncodedBlocks(config.getStringList("bunkers." + id + ".expansion-anchors"));
            Integer oxygenY = config.contains("bunkers." + id + ".oxygenY")
                    ? Integer.valueOf(config.getInt("bunkers." + id + ".oxygenY")) : null;
            int oxygenSeconds = config.getInt("bunkers." + id + ".oxygenSeconds", 0);
            int maxOxygenSeconds = config.getInt("bunkers." + id + ".maxOxygenSeconds", oxygenSeconds);
            ProtectedBunker bunker = new ProtectedBunker(
                    id, world, protectedBlocks, expansionAnchors,
                    config.getInt("bunkers." + id + ".minX"),
                    config.getInt("bunkers." + id + ".minY"),
                    config.getInt("bunkers." + id + ".minZ"),
                    config.getInt("bunkers." + id + ".maxX"),
                    config.getInt("bunkers." + id + ".maxY"),
                    config.getInt("bunkers." + id + ".maxZ"),
                    Math.max(1, config.getInt("bunkers." + id + ".wallThickness", 1)),
                    oxygenY, oxygenSeconds, maxOxygenSeconds);
            bunkers.put(id, bunker);
        }
    }

    public void reload() {
        load();
    }

    /** Создать бункер, сохранить его и создать клейм (тиму) на центральный чанк. */
    public ProtectedBunker addBunker(String worldName, Set protectedBlocks, Set expansionAnchors,
                                     int minX, int minY, int minZ, int maxX, int maxY, int maxZ,
                                     int wallThickness, Integer oxygenY, int initialOxygenSeconds, java.util.UUID owner) {
        String id = java.util.UUID.randomUUID().toString();
        ProtectedBunker bunker = new ProtectedBunker(id, worldName, protectedBlocks, expansionAnchors,
                minX, minY, minZ, maxX, maxY, maxZ, wallThickness, oxygenY,
                initialOxygenSeconds, initialOxygenSeconds);
        bunkers.put(id, bunker);
        writeBunker(bunker);
        save();
        if (owner != null && plugin.getClaimManager() != null) {
            int centerChunkX = Math.floorDiv(minX, 16);
            int centerChunkZ = Math.floorDiv(minZ, 16);
            plugin.getClaimManager().createClaim(java.util.UUID.fromString(id), worldName, centerChunkX, centerChunkZ, owner);
        }
        return bunker;
    }

    public boolean isProtectedShell(Block block) {
        World world = block.getWorld();
        Iterator it = bunkers.values().iterator();
        while (it.hasNext()) {
            ProtectedBunker bunker = (ProtectedBunker) it.next();
            if (bunker.isSameWorld(world) && bunker.isProtected(block)) {
                return true;
            }
        }
        return false;
    }

    public ProtectedBunker getBunkerAt(Location loc) {
        if (loc == null) return null;
        Iterator it = bunkers.values().iterator();
        while (it.hasNext()) {
            ProtectedBunker bunker = (ProtectedBunker) it.next();
            if (bunker.containsLocation(loc)) return bunker;
        }
        return null;
    }

    public ProtectedBunker getOxygenZoneAt(Location loc) {
        if (loc == null) return null;
        Iterator it = bunkers.values().iterator();
        while (it.hasNext()) {
            ProtectedBunker bunker = (ProtectedBunker) it.next();
            if (bunker.isInOxygenZone(loc)) return bunker;
        }
        return null;
    }

    public Collection getBunkers() {
        return new ArrayList(bunkers.values());
    }

    public ProtectedBunker getBunkerById(String id) {
        return id != null ? (ProtectedBunker) bunkers.get(id) : null;
    }

    public void replaceBunker(ProtectedBunker bunker) {
        bunkers.put(bunker.id(), bunker);
        writeBunker(bunker);
        save();
    }

    /** Сохранить текущие остатки кислорода всех бункеров. */
    public void saveOxygenState() {
        if (config == null) return;
        Iterator it = bunkers.values().iterator();
        while (it.hasNext()) {
            ProtectedBunker bunker = (ProtectedBunker) it.next();
            config.set("bunkers." + bunker.id() + ".oxygenSeconds", Integer.valueOf(bunker.oxygenSeconds()));
            config.set("bunkers." + bunker.id() + ".maxOxygenSeconds", Integer.valueOf(bunker.maxOxygenSeconds()));
        }
        save();
    }

    private void writeBunker(ProtectedBunker bunker) {
        String base = "bunkers." + bunker.id() + ".";
        config.set(base + "world", bunker.worldName());
        config.set(base + "minX", Integer.valueOf(bunker.minX()));
        config.set(base + "minY", Integer.valueOf(bunker.minY()));
        config.set(base + "minZ", Integer.valueOf(bunker.minZ()));
        config.set(base + "maxX", Integer.valueOf(bunker.maxX()));
        config.set(base + "maxY", Integer.valueOf(bunker.maxY()));
        config.set(base + "maxZ", Integer.valueOf(bunker.maxZ()));
        config.set(base + "wallThickness", Integer.valueOf(bunker.wallThickness()));
        config.set(base + "oxygenY", bunker.oxygenY());
        config.set(base + "oxygenSeconds", Integer.valueOf(bunker.oxygenSeconds()));
        config.set(base + "maxOxygenSeconds", Integer.valueOf(bunker.maxOxygenSeconds()));
        config.set(base + "protected-blocks", serializeEncodedBlocks(bunker.protectedBlocks()));
        config.set(base + "expansion-anchors", serializeEncodedBlocks(bunker.expansionAnchors()));
    }

    private Set parseEncodedBlocks(List list) {
        Set out = new HashSet();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            String s = (String) it.next();
            String[] parts = s.split(",");
            if (parts.length == 3) {
                try {
                    out.add(Long.valueOf(ProtectedBunker.encode(
                            Integer.parseInt(parts[0].trim()),
                            Integer.parseInt(parts[1].trim()),
                            Integer.parseInt(parts[2].trim()))));
                } catch (NumberFormatException ignored) {
                }
            }
        }
        return out;
    }

    private List serializeEncodedBlocks(Set blocks) {
        List out = new ArrayList();
        Iterator it = blocks.iterator();
        while (it.hasNext()) {
            long packed = ((Long) it.next()).longValue();
            out.add(unpackX(packed) + ", " + unpackY(packed) + ", " + unpackZ(packed));
        }
        return out;
    }

    private static int unpackX(long packed) {
        int x = (int) (packed >> 38);
        if (x >= 33554432) x -= 67108864;
        return x;
    }

    private static int unpackY(long packed) {
        int y = (int) (packed & 4095L);
        if (y >= 2048) y -= 4096;
        return y;
    }

    private static int unpackZ(long packed) {
        int z = (int) ((packed >> 12) & 67108863L);
        if (z >= 33554432) z -= 67108864;
        return z;
    }

    private void save() {
        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save bunkers.yml: " + e.getMessage());
        }
    }
}

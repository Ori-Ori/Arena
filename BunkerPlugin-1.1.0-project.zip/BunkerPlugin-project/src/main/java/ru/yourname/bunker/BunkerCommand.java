package ru.yourname.bunker;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.session.ClipboardHolder;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.BlockVector3;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.scheduler.BukkitRunnable;

/** /bunker — основная команда: стройка, отмена, инфо, тимы. */
public final class BunkerCommand implements TabExecutor {

    /** Причина отмены стройки. */
    private enum CancelReason { MANUAL, LEFT_CHUNK, SURFACE_CHANGED, QUIT, DIED, PLUGIN_SHUTDOWN }

    /** Тип бункера из секции bunkers (случайный выбор по весу). */
    private static final class BunkerTemplate {
        private final String id, schematicFile, maskFile;
        private final int weight;
        BunkerTemplate(String id, String schematicFile, String maskFile, int weight) {
            this.id = id; this.schematicFile = schematicFile; this.maskFile = maskFile; this.weight = weight;
        }
        String id() { return id; }
        String schematicFile() { return schematicFile; }
        String maskFile() { return maskFile; }
        int weight() { return weight; }
    }

    /** Запись цены: материал + количество. */
    private static final class CostEntry {
        private final Material material;
        private final int amount;
        CostEntry(Material material, int amount) { this.material = material; this.amount = amount; }
        Material material() { return material; }
        int amount() { return amount; }
    }

    /** Мировые границы вставленной схематики. */
    private static final class PlacementInfo {
        private final String worldName;
        private final int minX, minY, minZ, maxX, maxY, maxZ;
        PlacementInfo(String worldName, int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
            this.worldName = worldName;
            this.minX = minX; this.minY = minY; this.minZ = minZ;
            this.maxX = maxX; this.maxY = maxY; this.maxZ = maxZ;
        }
        String worldName() { return worldName; }
        int minX() { return minX; } int minY() { return minY; } int minZ() { return minZ; }
        int maxX() { return maxX; } int maxY() { return maxY; } int maxZ() { return maxZ; }
    }

    /** Результат валидации чанка. */
    private static final class ValidationResult {
        private final boolean success;
        private final String messageKey;
        private ValidationResult(boolean success, String messageKey) { this.success = success; this.messageKey = messageKey; }
        static ValidationResult ok() { return new ValidationResult(true, null); }
        static ValidationResult fail(String key) { return new ValidationResult(false, key); }
        boolean success() { return success; }
        String messageKey() { return messageKey; }
    }

    private final BunkerPlugin plugin;
    private final Map sessions = new HashMap(); // Map<UUID, BuildSession>

    public BunkerCommand(BunkerPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            send(sender, "usage");
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (sub.equals("reload")) {
            if (!sender.hasPermission("bunker.reload")) {
                send(sender, "no-permission");
                return true;
            }
            plugin.reloadAll();
            send(sender, "reloaded");
            return true;
        }
        if (sub.equals("create")) {
            if (!(sender instanceof Player)) { send(sender, "only-player"); return true; }
            Player player = (Player) sender;
            if (!player.hasPermission("bunker.create")) { send(sender, "no-permission"); return true; }
            prepareBuild(player);
            return true;
        }
        if (sub.equals("cancel")) {
            if (!(sender instanceof Player)) { send(sender, "only-player"); return true; }
            BuildSession session = (BuildSession) sessions.get(((Player) sender).getUniqueId());
            if (session != null) {
                session.stop(CancelReason.MANUAL);
            } else {
                send(sender, "no-active-build");
            }
            return true;
        }
        if (sub.equals("info")) {
            if (!(sender instanceof Player)) { send(sender, "only-player"); return true; }
            Player player = (Player) sender;
            ProtectedBunker bunker = plugin.getBunkerManager().getBunkerAt(player.getLocation());
            if (bunker == null) { send(sender, "info-outside"); return true; }
            send(sender, "info", ControlPanelMenu.mapOf(
                    "oxygen", OxygenService.formatTime(bunker.oxygenSeconds()),
                    "max", OxygenService.formatTime(bunker.maxOxygenSeconds()),
                    "y", bunker.oxygenY() != null ? String.valueOf(bunker.oxygenY()) : "-",
                    "zone", bunker.isInOxygenZone(player.getLocation()) ? "да" : "нет"));
            return true;
        }
        if (sub.equals("invite")) return handleInvite(sender, args);
        if (sub.equals("accept")) return handleAccept(sender, args);
        if (sub.equals("deny")) return handleDeny(sender, args);
        if (sub.equals("give")) return handleGive(sender, args);
        if (sub.equals("deputy")) return handleDeputy(sender, args);
        send(sender, "usage");
        return true;
    }

    @Override
    public List onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Arrays.asList(new String[]{"reload", "create", "cancel", "info", "invite", "accept", "deny", "give", "deputy"});
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("deputy")) {
            return Arrays.asList(new String[]{"add", "remove"});
        }
        return Collections.emptyList();
    }

    public boolean isBuilding(UUID uuid) {
        return sessions.containsKey(uuid);
    }

    public void cancelActiveBuilds() {
        Iterator it = new ArrayList(sessions.values()).iterator();
        while (it.hasNext()) {
            ((BuildSession) it.next()).stop(CancelReason.PLUGIN_SHUTDOWN);
        }
        sessions.clear();
    }

    // ==================== Тимы ====================

    private boolean handleInvite(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) { send(sender, "only-player"); return true; }
        Player player = (Player) sender;
        if (args.length < 2) { send(sender, "usage-invite"); return true; }
        BunkerClaim claim = plugin.getClaimManager().findClaimWhereCanManage(player);
        if (claim == null) claim = plugin.getClaimManager().ensureClaimForPlayerGrid(player, player.getLocation());
        if (claim == null) { send(sender, "claim-not-authorized"); return true; }
        Player target = org.bukkit.Bukkit.getPlayerExact(args[1]);
        if (target == null) { send(sender, "user-not-found"); return true; }
        if (target.getUniqueId().equals(player.getUniqueId())) { send(sender, "cannot-invite-self"); return true; }
        if (claim.isMember(target.getUniqueId())) { send(sender, "already-member"); return true; }
        if (plugin.getClaimManager().findClaimWhereMember(target) != null) {
            send(sender, "already-in-other-bunker");
            return true;
        }
        claim.invite(target.getUniqueId());
        plugin.getClaimManager().save();
        send(sender, "invite-sent", ControlPanelMenu.mapOf("player", target.getName()));
        plugin.sendMessage(target, "invite-received", ControlPanelMenu.mapOf("leader", player.getName()));
        return true;
    }

    /** /bunker give <глава> — отправить запрос на вступление главе. */
    private boolean handleGive(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) { send(sender, "only-player"); return true; }
        Player player = (Player) sender;
        if (args.length < 2) { send(sender, "usage-give"); return true; }
        Player leader = org.bukkit.Bukkit.getPlayerExact(args[1]);
        if (leader == null) { send(sender, "user-not-found"); return true; }
        if (leader.getUniqueId().equals(player.getUniqueId())) { send(sender, "cannot-request-self"); return true; }
        BunkerClaim claim = plugin.getClaimManager().findClaimWhereMember(leader);
        if (claim == null) claim = plugin.getClaimManager().ensureClaimForPlayerGrid(leader, leader.getLocation());
        if (claim == null) { send(sender, "target-not-in-bunker"); return true; }
        if (claim.isMember(player.getUniqueId())) { send(sender, "already-member"); return true; }
        BunkerClaim mine = plugin.getClaimManager().findClaimWhereMember(player);
        if (mine != null && mine != claim) { send(sender, "already-in-other-bunker"); return true; }
        claim.requestJoin(player.getUniqueId());
        plugin.getClaimManager().save();
        send(sender, "join-request-sent", ControlPanelMenu.mapOf("leader", leader.getName()));
        Iterator it = claim.leadersAndDeputies().iterator();
        while (it.hasNext()) {
            Player manager = org.bukkit.Bukkit.getPlayer((UUID) it.next());
            if (manager != null) {
                plugin.sendMessage(manager, "join-request-received", ControlPanelMenu.mapOf("player", player.getName()));
            }
        }
        return true;
    }

    private boolean handleAccept(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) { send(sender, "only-player"); return true; }
        Player player = (Player) sender;
        // 1) есть приглашение — принимаем его
        BunkerClaim invited = plugin.getClaimManager().findClaimWithInviteFor(player.getUniqueId());
        if (invited != null) {
            BunkerClaim mine = plugin.getClaimManager().findClaimWhereMember(player);
            if (mine != null && mine != invited) {
                invited.denyInvite(player.getUniqueId());
                plugin.getClaimManager().save();
                send(sender, "already-in-other-bunker");
                return true;
            }
            invited.acceptInvite(player.getUniqueId());
            plugin.getClaimManager().save();
            send(sender, "invite-accepted");
            Iterator it = invited.leadersAndDeputies().iterator();
            while (it.hasNext()) {
                Player manager = org.bukkit.Bukkit.getPlayer((UUID) it.next());
                if (manager != null) {
                    plugin.sendMessage(manager, "member-joined", ControlPanelMenu.mapOf("player", player.getName()));
                }
            }
            return true;
        }
        // 2) иначе — принимаем заявку игрока в свой бункер (глава/зам)
        BunkerClaim claim = plugin.getClaimManager().findClaimWithRequestForManager(player);
        if (claim == null) claim = plugin.getClaimManager().ensureClaimForPlayerGrid(player, player.getLocation());
        if (claim != null && (!claim.canManage(player.getUniqueId()) || claim.requests().isEmpty())) claim = null;
        if (claim == null) { send(sender, "no-pending-request"); return true; }
        UUID applicant = ((BunkerClaim.JoinRequest) claim.requests().get(0)).playerId();
        BunkerClaim other = plugin.getClaimManager().findClaimWhereMember(applicant);
        if (other != null && other != claim) {
            claim.denyRequest(applicant);
            plugin.getClaimManager().save();
            send(sender, "already-in-other-bunker");
            return true;
        }
        claim.acceptRequest(applicant);
        plugin.getClaimManager().save();
        send(sender, "request-accepted");
        Player joined = org.bukkit.Bukkit.getPlayer(applicant);
        if (joined != null) {
            plugin.sendMessage(joined, "request-accepted-player", ControlPanelMenu.mapOf("leader", player.getName()));
        }
        return true;
    }

    private boolean handleDeny(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) { send(sender, "only-player"); return true; }
        Player player = (Player) sender;
        BunkerClaim invited = plugin.getClaimManager().findClaimWithInviteFor(player.getUniqueId());
        if (invited != null) {
            invited.denyInvite(player.getUniqueId());
            plugin.getClaimManager().save();
            send(sender, "invite-denied");
            return true;
        }
        BunkerClaim claim = plugin.getClaimManager().findClaimWithRequestForManager(player);
        if (claim == null) claim = plugin.getClaimManager().ensureClaimForPlayerGrid(player, player.getLocation());
        if (claim != null && (!claim.canManage(player.getUniqueId()) || claim.requests().isEmpty())) claim = null;
        if (claim == null) { send(sender, "no-pending-request"); return true; }
        UUID applicant = ((BunkerClaim.JoinRequest) claim.requests().get(0)).playerId();
        claim.denyRequest(applicant);
        plugin.getClaimManager().save();
        send(sender, "request-denied");
        Player rejected = org.bukkit.Bukkit.getPlayer(applicant);
        if (rejected != null) {
            plugin.sendMessage(rejected, "request-denied-player");
        }
        return true;
    }

    private boolean handleDeputy(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) { send(sender, "only-player"); return true; }
        Player player = (Player) sender;
        if (args.length < 3) { send(sender, "usage-deputy"); return true; }
        BunkerClaim claim = plugin.getClaimManager().findClaimWhereLeader(player);
        if (claim == null) claim = plugin.getClaimManager().ensureClaimForPlayerGrid(player, player.getLocation());
        if (claim == null) { send(sender, "claim-not-authorized"); return true; }
        Player target = org.bukkit.Bukkit.getPlayerExact(args[2]);
        if (target == null) { send(sender, "user-not-found"); return true; }
        if (args[1].equalsIgnoreCase("add")) {
            if (claim.isDeputy(target.getUniqueId())) { send(sender, "already-deputy"); return true; }
            if (!claim.isMember(target.getUniqueId())
                    && plugin.getClaimManager().findClaimWhereMember(target) != null) {
                send(sender, "already-in-other-bunker");
                return true;
            }
            if (!claim.isMember(target.getUniqueId())) claim.addMember(target.getUniqueId());
            claim.addDeputy(target.getUniqueId());
            plugin.getClaimManager().save();
            send(sender, "deputy-added", ControlPanelMenu.mapOf("player", target.getName()));
            plugin.sendMessage(target, "you-are-deputy", ControlPanelMenu.mapOf("leader", player.getName()));
        } else if (args[1].equalsIgnoreCase("remove")) {
            if (!claim.isDeputy(target.getUniqueId())) { send(sender, "not-a-deputy"); return true; }
            claim.removeDeputy(target.getUniqueId());
            plugin.getClaimManager().save();
            send(sender, "deputy-removed", ControlPanelMenu.mapOf("player", target.getName()));
            plugin.sendMessage(target, "you-are-not-deputy");
        } else {
            send(sender, "usage-deputy");
        }
        return true;
    }

    // ==================== Стройка ====================

    private void prepareBuild(Player player) {
        if (sessions.containsKey(player.getUniqueId())) {
            send(player, "already-building");
            return;
        }
        FileConfiguration config = plugin.getConfig();
        Chunk chunk = player.getLocation().getChunk();
        World world = player.getWorld();

        ValidationResult validation = validateChunk(chunk, world);
        if (!validation.success()) {
            send(player, validation.messageKey());
            return;
        }
        List costs = parseCosts(config.getStringList("creation-cost"));
        if (costs == null) {
            send(player, "invalid-config-cost");
            return;
        }
        Map missing = getMissingResources(player, costs);
        if (!missing.isEmpty()) {
            StringBuilder list = new StringBuilder();
            Iterator it = missing.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry entry = (Map.Entry) it.next();
                if (list.length() > 0) list.append(", ");
                list.append(getMaterialDisplayNameRu((Material) entry.getKey()))
                    .append(" x").append(((Integer) entry.getValue()).intValue());
            }
            send(player, "not-enough-resources", ControlPanelMenu.mapOf("list", list.toString()));
            return;
        }
        List templates = loadBunkerTemplates(config);
        if (templates.isEmpty()) {
            send(player, "bunkers-not-configured");
            return;
        }
        BunkerTemplate template = pickRandomTemplate(templates);
        send(player, "selected-bunker", ControlPanelMenu.mapOf("id", template.id()));

        File schematicFile = new File(plugin.getSchematicsFolder(), template.schematicFile());
        if (!schematicFile.exists()) {
            send(player, "schematic-not-found", ControlPanelMenu.mapOf("file", schematicFile.getName()));
            return;
        }
        Clipboard clipboard;
        try {
            clipboard = loadClipboard(schematicFile);
        } catch (Exception e) {
            send(player, "worldedit-error", ControlPanelMenu.mapOf("error", e.getMessage() != null ? e.getMessage() : "unknown"));
            return;
        }
        BlockVector3 dimensions = clipboard.getDimensions();
        if (dimensions.x() > 16 || dimensions.z() > 16) {
            send(player, "schematic-too-large");
            return;
        }

        String protectionMode = config.getString("protection.mode", "mask").toLowerCase(Locale.ROOT);
        boolean maskMode = protectionMode.equals("mask");
        Material markerMaterial = null;
        Clipboard maskClipboard = null;
        if (maskMode) {
            markerMaterial = Material.matchMaterial(config.getString("protection.marker-material", "ORANGE_WOOL").toUpperCase(Locale.ROOT));
            if (markerMaterial == null || !markerMaterial.isBlock()) {
                send(player, "mask-invalid-material", ControlPanelMenu.mapOf("material", String.valueOf(config.getString("protection.marker-material"))));
                return;
            }
            String maskFile = template.maskFile();
            if (maskFile == null || maskFile.trim().isEmpty()) {
                maskFile = config.getString("protection.mask-file", "bunker_mask.schem");
            }
            File mask = new File(plugin.getSchematicsFolder(), maskFile);
            if (!mask.exists()) {
                send(player, "mask-not-found", ControlPanelMenu.mapOf("file", mask.getName()));
                return;
            }
            try {
                maskClipboard = loadClipboard(mask);
            } catch (Exception e) {
                send(player, "worldedit-error", ControlPanelMenu.mapOf("error", e.getMessage() != null ? e.getMessage() : "unknown"));
                return;
            }
            BlockVector3 maskDims = maskClipboard.getDimensions();
            if (maskDims.x() > 16 || maskDims.z() > 16) {
                send(player, "schematic-too-large");
                return;
            }
            if (maskDims.x() != dimensions.x() || maskDims.y() != dimensions.y() || maskDims.z() != dimensions.z()) {
                send(player, "mask-size-mismatch", ControlPanelMenu.mapOf("file", mask.getName()));
                return;
            }
            if (countMarkerBlocks(maskClipboard, markerMaterial) <= 0) {
                send(player, "mask-no-markers", ControlPanelMenu.mapOf("material", markerMaterial.name()));
                return;
            }
        }

        int seconds = Math.max(1, config.getInt("progress.seconds", 30));
        int barLength = Math.max(4, config.getInt("progress.bar-length", 12));
        boolean cancelOnLeaveChunk = config.getBoolean("progress.cancel-on-leave-chunk", true);
        boolean cancelOnSurfaceChange = config.getBoolean("progress.cancel-on-surface-change", true);
        String barLabel = config.getString("progress.label", "БУНКЕР");

        // === ТОЧКА СТАРТА: от какого Y строится бункер ===
        int baseY = resolveBaseY(player, chunk, world, config);

        takeResources(player, costs);
        send(player, "resources-taken");
        BuildSession session = new BuildSession(player, chunk, world, costs, clipboard, maskClipboard,
                markerMaterial, protectionMode, baseY, seconds * 20, barLength,
                cancelOnLeaveChunk, cancelOnSurfaceChange, snapshotSurface(chunk, world), barLabel);
        sessions.put(player.getUniqueId(), session);
        session.start();
        send(player, "build-started", ControlPanelMenu.mapOf("seconds", String.valueOf(seconds)));
    }

    /**
     * Точка старта по вертикали (creation.* в config.yml):
     *   PLAYER  — Y игрока + schematic.paste-y-offset + creation.player-y-offset (старое поведение);
     *   SURFACE — уровень поверхности чанка (высший блок + 1) + creation.surface-y-offset;
     *   FIXED   — абсолютная высота creation.fixed-y.
     * Бункер вставляется по центру чанка независимо от того, стоит/прыгает/летит игрок.
     */
    private int resolveBaseY(Player player, Chunk chunk, World world, FileConfiguration config) {
        String anchor = config.getString("creation.anchor", "SURFACE");
        if (anchor == null) anchor = "SURFACE";
        anchor = anchor.trim().toUpperCase(Locale.ROOT);
        if (anchor.equals("FIXED")) {
            return config.getInt("creation.fixed-y", 64);
        }
        if (anchor.equals("PLAYER")) {
            return player.getLocation().getBlockY()
                    + config.getInt("schematic.paste-y-offset", 0)
                    + config.getInt("creation.player-y-offset", 0);
        }
        // SURFACE (по умолчанию): поверхность по центру чанка
        int centerBlockX = (chunk.getX() << 4) + 8;
        int centerBlockZ = (chunk.getZ() << 4) + 8;
        int surfaceY = world.getHighestBlockYAt(centerBlockX, centerBlockZ) + 1;
        return surfaceY + config.getInt("creation.surface-y-offset", 0);
    }

    /** Список шаблонов из секции bunkers (+ legacy fallback schematic.file). */
    private List loadBunkerTemplates(FileConfiguration config) {
        List out = new ArrayList();
        Iterator it = config.getMapList("bunkers").iterator();
        while (it.hasNext()) {
            Map raw = (Map) it.next();
            Object schematic = raw.get("schematic-file");
            if (!(schematic instanceof String)) continue;
            String schematicFile = (String) schematic;
            if (schematicFile.trim().isEmpty()) continue;
            Object idObj = raw.containsKey("id") ? raw.get("id") : null;
            String id = idObj != null ? String.valueOf(idObj) : "bunker_" + schematicFile;
            Object mask = raw.get("mask-file");
            out.add(new BunkerTemplate(id, schematicFile, mask instanceof String ? (String) mask : "",
                    parsePositiveInt(raw.get("weight"), 1)));
        }
        if (!out.isEmpty()) return out;
        String legacy = config.getString("schematic.file", "");
        if (legacy != null && !legacy.trim().isEmpty()) {
            out.add(new BunkerTemplate("legacy", legacy, config.getString("protection.mask-file", ""), 1));
        }
        return out;
    }

    /** Случайный шаблон пропорционально весам. */
    private BunkerTemplate pickRandomTemplate(List templates) {
        int total = 0;
        Iterator it = templates.iterator();
        while (it.hasNext()) total += Math.max(1, ((BunkerTemplate) it.next()).weight());
        if (total <= 0) return (BunkerTemplate) templates.get(0);
        int roll = ThreadLocalRandom.current().nextInt(total);
        int acc = 0;
        Iterator iter = templates.iterator();
        while (iter.hasNext()) {
            BunkerTemplate template = (BunkerTemplate) iter.next();
            acc += Math.max(1, template.weight());
            if (roll < acc) return template;
        }
        return (BunkerTemplate) templates.get(0);
    }

    private static int parsePositiveInt(Object o, int def) {
        if (o == null) return def;
        if (o instanceof Number) return Math.max(1, ((Number) o).intValue());
        try {
            return Math.max(1, Integer.parseInt(String.valueOf(o)));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    // ==================== WorldEdit ====================

    /** Вставить схематику по центру чанка на высоте baseY. */
    private PlacementInfo pasteBunker(Chunk chunk, World world, Clipboard clipboard, int baseY) {
        BlockVector3 to = getCenteredPastePosition(chunk, clipboard, baseY);
        com.sk89q.worldedit.world.World weWorld = BukkitAdapter.adapt(world);
        EditSession session = WorldEdit.getInstance().newEditSession(weWorld);
        try {
            Operation operation = new ClipboardHolder(clipboard)
                    .createPaste(session)
                    .to(to)
                    .ignoreAirBlocks(false)
                    .build();
            Operations.complete(operation);
        } catch (Exception e) {
            if (session != null) {
                try {
                    session.close();
                } catch (Exception suppressed) {
                    e.addSuppressed(suppressed);
                }
            }
            throw e;
        }
        if (session != null) {
            session.close();
        }
        return buildPlacementInfo(world.getName(), clipboard, to);
    }

    private PlacementInfo buildPlacementInfo(String worldName, Clipboard clipboard, BlockVector3 to) {
        BlockVector3 min = clipboard.getMinimumPoint();
        BlockVector3 max = clipboard.getMaximumPoint();
        BlockVector3 origin = clipboard.getOrigin();
        return new PlacementInfo(worldName,
                to.x() + (min.x() - origin.x()), to.y() + (min.y() - origin.y()), to.z() + (min.z() - origin.z()),
                to.x() + (max.x() - origin.x()), to.y() + (max.y() - origin.y()), to.z() + (max.z() - origin.z()));
    }

    /** Сколько блоков-маркеров в маске. */
    private int countMarkerBlocks(Clipboard clipboard, Material marker) {
        String markerKey = marker.getKey().toString();
        Iterator it = clipboard.getRegion().iterator();
        int count = 0;
        while (it.hasNext()) {
            if (markerKey.equalsIgnoreCase(clipboard.getBlock((BlockVector3) it.next()).getBlockType().id())) {
                count++;
            }
        }
        return count;
    }

    /** Максимальный Y маркеров кислорода (PURPLE_WOOL) — ниже него кислородная зона. */
    private Integer resolveOxygenY(Clipboard maskClipboard, BlockVector3 to, Material marker) {
        if (maskClipboard == null || marker == null) return null;
        String markerKey = marker.getKey().toString();
        BlockVector3 origin = maskClipboard.getOrigin();
        Iterator it = maskClipboard.getRegion().iterator();
        Integer oxygenY = null;
        while (it.hasNext()) {
            BlockVector3 pos = (BlockVector3) it.next();
            if (markerKey.equalsIgnoreCase(maskClipboard.getBlock(pos).getBlockType().id())) {
                int worldY = to.y() + (pos.y() - origin.y());
                if (oxygenY == null || worldY > oxygenY.intValue()) {
                    oxygenY = Integer.valueOf(worldY);
                }
            }
        }
        return oxygenY;
    }

    /** Защищённые блоки: все маркеры стен из маск-схемы -> мировые long-координаты. */
    private Set resolveProtectedBlocks(Clipboard maskClipboard, BlockVector3 to, Material marker) {
        Set out = new HashSet();
        if (maskClipboard == null || marker == null) return out;
        String markerKey = marker.getKey().toString();
        BlockVector3 origin = maskClipboard.getOrigin();
        Iterator it = maskClipboard.getRegion().iterator();
        while (it.hasNext()) {
            BlockVector3 pos = (BlockVector3) it.next();
            if (markerKey.equalsIgnoreCase(maskClipboard.getBlock(pos).getBlockType().id())) {
                out.add(Long.valueOf(ProtectedBunker.encode(
                        to.x() + (pos.x() - origin.x()),
                        to.y() + (pos.y() - origin.y()),
                        to.z() + (pos.z() - origin.z()))));
            }
        }
        return out;
    }

    /** Позиция вставки: центр чанка, baseY — нижняя граница схематики. */
    private BlockVector3 getCenteredPastePosition(Chunk chunk, Clipboard clipboard, int baseY) {
        int chunkBlockX = chunk.getX() << 4;
        int chunkBlockZ = chunk.getZ() << 4;
        BlockVector3 min = clipboard.getMinimumPoint();
        BlockVector3 origin = clipboard.getOrigin();
        BlockVector3 dims = clipboard.getDimensions();
        int x = chunkBlockX + (16 - dims.x()) / 2;
        int z = chunkBlockZ + (16 - dims.z()) / 2;
        return BlockVector3.at(x - (min.x() - origin.x()), baseY - (min.y() - origin.y()), z - (min.z() - origin.z()));
    }

    private Clipboard loadClipboard(File file) throws Exception {
        ClipboardFormat format = ClipboardFormats.findByFile(file);
        if (format == null) {
            throw new IllegalArgumentException("Unsupported schematic format: " + file.getName());
        }
        ClipboardReader reader = format.getReader((InputStream) new FileInputStream(file));
        try {
            return reader.read();
        } finally {
            reader.close();
        }
    }

    // ==================== Валидация и ресурсы ====================

    /** Снимок высот 16x16 для контроля изменений поверхности. */
    private int[] snapshotSurface(Chunk chunk, World world) {
        int[] heights = new int[256];
        int baseX = chunk.getX() << 4;
        int baseZ = chunk.getZ() << 4;
        int i = 0;
        for (int x = baseX; x < baseX + 16; x++) {
            for (int z = baseZ; z < baseZ + 16; z++) {
                heights[i++] = world.getHighestBlockYAt(x, z);
            }
        }
        return heights;
    }

    private boolean hasSurfaceChanged(Chunk chunk, World world, int[] snapshot) {
        if (snapshot == null) return false;
        int baseX = chunk.getX() << 4;
        int baseZ = chunk.getZ() << 4;
        int i = 0;
        for (int x = baseX; x < baseX + 16; x++) {
            for (int z = baseZ; z < baseZ + 16; z++) {
                if (world.getHighestBlockYAt(x, z) != snapshot[i]) return true;
                i++;
            }
        }
        return false;
    }

    /** Чанк ровный (все 256 высот равны) и без деревьев/растительности. */
    private ValidationResult validateChunk(Chunk chunk, World world) {
        int baseX = chunk.getX() << 4;
        int baseZ = chunk.getZ() << 4;
        Integer surfaceY = null;
        for (int x = baseX; x < baseX + 16; x++) {
            for (int z = baseZ; z < baseZ + 16; z++) {
                int y = world.getHighestBlockYAt(x, z);
                if (isTreeOrFoliage(world.getBlockAt(x, y, z).getType())) {
                    return ValidationResult.fail("need-remove-trees");
                }
                if (surfaceY == null) surfaceY = Integer.valueOf(y);
                else if (y != surfaceY.intValue()) return ValidationResult.fail("need-clear-chunk");
            }
        }
        return ValidationResult.ok();
    }

    private static final Set FOLIAGE = new HashSet(Arrays.asList(new Material[]{
            Material.SHORT_GRASS, Material.TALL_GRASS, Material.FERN, Material.LARGE_FERN,
            Material.DEAD_BUSH, Material.DANDELION, Material.POPPY, Material.BLUE_ORCHID,
            Material.ALLIUM, Material.AZURE_BLUET, Material.RED_TULIP, Material.ORANGE_TULIP,
            Material.WHITE_TULIP, Material.PINK_TULIP, Material.OXEYE_DAISY, Material.CORNFLOWER,
            Material.LILY_OF_THE_VALLEY, Material.WITHER_ROSE, Material.SUNFLOWER, Material.LILAC,
            Material.ROSE_BUSH, Material.PEONY, Material.BROWN_MUSHROOM, Material.RED_MUSHROOM,
            Material.SNOW
    }));

    private boolean isTreeOrFoliage(Material material) {
        if (material == null) return false;
        String name = material.name();
        if (name.contains("LEAVES")) return true;
        if (name.endsWith("_LOG") || name.endsWith("_WOOD")) return true;
        if (name.contains("SAPLING")) return true;
        return FOLIAGE.contains(material);
    }

    /** "STONE:64" -> CostEntry; null при ошибке конфига. */
    private List parseCosts(List raw) {
        List out = new ArrayList();
        try {
            Iterator it = raw.iterator();
            while (it.hasNext()) {
                String[] parts = ((String) it.next()).split(":");
                if (parts.length != 2) return null;
                Material material = Material.matchMaterial(parts[0].trim().toUpperCase(Locale.ROOT));
                if (material == null) return null;
                int amount = Integer.parseInt(parts[1].trim());
                if (amount <= 0) return null;
                out.add(new CostEntry(material, amount));
            }
        } catch (Exception e) {
            return null;
        }
        return out;
    }

    private Map getMissingResources(Player player, List costs) {
        Map missing = new LinkedHashMap();
        Iterator it = costs.iterator();
        while (it.hasNext()) {
            CostEntry cost = (CostEntry) it.next();
            int have = countMaterial(player, cost.material());
            if (have < cost.amount()) {
                missing.put(cost.material(), Integer.valueOf(cost.amount() - have));
            }
        }
        return missing;
    }

    private int countMaterial(Player player, Material material) {
        ItemStack[] contents = player.getInventory().getContents();
        int count = 0;
        for (int i = 0; i < contents.length; i++) {
            ItemStack item = contents[i];
            if (item != null && item.getType() == material) count += item.getAmount();
        }
        return count;
    }

    private void takeResources(Player player, List costs) {
        ItemStack[] contents = player.getInventory().getContents();
        Iterator it = costs.iterator();
        while (it.hasNext()) {
            CostEntry cost = (CostEntry) it.next();
            int remaining = cost.amount();
            for (int i = 0; i < contents.length && remaining > 0; i++) {
                ItemStack item = contents[i];
                if (item != null && item.getType() == cost.material()) {
                    int take = Math.min(item.getAmount(), remaining);
                    item.setAmount(item.getAmount() - take);
                    remaining -= take;
                    if (item.getAmount() <= 0) contents[i] = null;
                }
            }
        }
        player.getInventory().setContents(contents);
        player.updateInventory();
    }

    private void giveBackOrDrop(Player player, List costs) {
        Iterator it = costs.iterator();
        while (it.hasNext()) {
            CostEntry cost = (CostEntry) it.next();
            ItemStack stack = new ItemStack(cost.material(), cost.amount());
            PlayerInventory inventory = player.getInventory();
            Map leftover = inventory.addItem(new ItemStack[]{stack});
            if (!leftover.isEmpty()) {
                Iterator dropIt = leftover.values().iterator();
                while (dropIt.hasNext()) {
                    player.getWorld().dropItemNaturally(player.getLocation(), (ItemStack) dropIt.next());
                }
            }
        }
        player.updateInventory();
    }

    // ==================== Сообщения и прогресс-бар ====================

    private void send(CommandSender sender, String key) {
        send(sender, key, Collections.emptyMap());
    }

    private void send(CommandSender sender, String key, Map placeholders) {
        plugin.sendMessage(sender, key, placeholders);
    }

    /** Градиентный актионбар: ⛏ БУНКЕР  ▓▓▓░░ 12с */
    private Component buildBar(int filled, int length, int secondsLeft, String label) {
        length = Math.max(1, length);
        TextColor headColor = gradient((float) filled / (float) length);
        Component bar = Component.empty().decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false)
                .append(Component.text("\u26cf ").color(headColor))
                .append(Component.text(label + "  ").color(TextColor.color(14870768)));
        for (int i = 0; i < length; i++) {
            if (i >= filled) {
                bar = bar.append(Component.text("\u2591").color(rgb(58, 64, 70)));
            } else {
                float progress = length > 1 ? (float) i / (float) (length - 1) : 0f;
                bar = bar.append(Component.text("\u2588").color(gradient(progress)));
            }
        }
        bar = bar.append(Component.text(" " + secondsLeft + "с").color(TextColor.color(14870768)));
        return bar;
    }

    /** От зелёного через жёлтый к красному. */
    private TextColor gradient(float t) {
        if (t < 0f) t = 0f;
        if (t > 1f) t = 1f;
        int[] green = {52, 211, 120};
        int[] yellow = {250, 204, 21};
        int[] red = {239, 68, 68};
        if (t < 0.5f) return lerp(green, yellow, t / 0.5f);
        return lerp(yellow, red, (t - 0.5f) / 0.5f);
    }

    private TextColor lerp(int[] from, int[] to, float t) {
        return rgb(
                Math.round(from[0] + (to[0] - from[0]) * t),
                Math.round(from[1] + (to[1] - from[1]) * t),
                Math.round(from[2] + (to[2] - from[2]) * t));
    }

    private TextColor rgb(int r, int g, int b) {
        return TextColor.color(((r & 255) << 16) | ((g & 255) << 8) | (b & 255));
    }

    private String getMaterialDisplayNameRu(Material material) {
        String name = plugin.getMaterials().getString("names." + material.name().toLowerCase(Locale.ROOT));
        if (name != null && !name.trim().isEmpty()) return name;
        if (material == Material.COBBLESTONE) {
            String legacy = plugin.getMaterials().getString("names.cobbestone");
            if (legacy != null && !legacy.trim().isEmpty()) return legacy;
        }
        return material.name().toLowerCase(Locale.ROOT).replace('_', ' ');
    }

    // ==================== Сессия стройки ====================

    /** Активная стройка: тик 4 раза/сек, прогресс-бар, биперы, вставка по завершении. */
    private final class BuildSession {

        private final Player player;
        private final Chunk chunk;
        private final World world;
        private final List costs;
        private final Clipboard clipboard;
        private final Clipboard maskClipboard;
        private final Material markerMaterial;
        private final String protectionMode;
        private final int baseY;
        private final int totalTicks;
        private final int barLength;
        private final boolean cancelOnLeaveChunk;
        private final boolean cancelOnSurfaceChange;
        private final int[] surfaceSnapshot;
        private final String barLabel;
        private int elapsedTicks;
        private int lastBeepSecond = -1;
        private BukkitRunnable task;

        BuildSession(Player player, Chunk chunk, World world, List costs, Clipboard clipboard,
                     Clipboard maskClipboard, Material markerMaterial, String protectionMode, int baseY,
                     int totalTicks, int barLength, boolean cancelOnLeaveChunk, boolean cancelOnSurfaceChange,
                     int[] surfaceSnapshot, String barLabel) {
            this.player = player;
            this.chunk = chunk;
            this.world = world;
            this.costs = costs;
            this.clipboard = clipboard;
            this.maskClipboard = maskClipboard;
            this.markerMaterial = markerMaterial;
            this.protectionMode = protectionMode;
            this.baseY = baseY;
            this.totalTicks = totalTicks;
            this.barLength = barLength;
            this.cancelOnLeaveChunk = cancelOnLeaveChunk;
            this.cancelOnSurfaceChange = cancelOnSurfaceChange;
            this.surfaceSnapshot = surfaceSnapshot;
            this.barLabel = (barLabel == null || barLabel.trim().isEmpty()) ? "БУНКЕР" : barLabel;
        }

        void start() {
            renderBar();
            task = new BukkitRunnable() {
                @Override
                public void run() {
                    tick();
                }
            };
            task.runTaskTimer(plugin, 5L, 5L);
        }

        private void tick() {
            if (player == null || !player.isOnline() || player.isDead()) {
                stop(CancelReason.QUIT);
                return;
            }
            if (cancelOnLeaveChunk) {
                Location loc = player.getLocation();
                if (loc.getChunk().getX() != chunk.getX() || loc.getChunk().getZ() != chunk.getZ()) {
                    stop(CancelReason.LEFT_CHUNK);
                    return;
                }
            }
            if (cancelOnSurfaceChange && hasSurfaceChanged(chunk, world, surfaceSnapshot)) {
                stop(CancelReason.SURFACE_CHANGED);
                return;
            }
            elapsedTicks += 5;
            renderBar();
            int secondsLeft = Math.max(0, (int) Math.ceil((double) (totalTicks - elapsedTicks) / 20.0));
            if (secondsLeft != lastBeepSecond && secondsLeft > 0 && secondsLeft <= 5) {
                lastBeepSecond = secondsLeft;
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.8f, 1f + (5 - secondsLeft) * 0.15f);
            }
            if (elapsedTicks >= totalTicks) {
                finish();
            }
        }

        private void renderBar() {
            int filled = Math.round((float) barLength * Math.min(1f, (float) elapsedTicks / (float) totalTicks));
            if (filled > barLength) filled = barLength;
            int secondsLeft = Math.max(0, (int) Math.ceil((double) (totalTicks - elapsedTicks) / 20.0));
            player.sendActionBar(buildBar(filled, barLength, secondsLeft, barLabel));
        }

        private void finish() {
            cancelTask();
            sessions.remove(player.getUniqueId());
            try {
                PlacementInfo placement = pasteBunker(chunk, world, clipboard, baseY);
                int wallThickness = Math.max(1, plugin.getConfig().getInt("protection.wall-thickness", 1));
                int initialOxygen = Math.max(0, plugin.getConfig().getInt("oxygen.initial-minutes", 30)) * 60;
                Set protectedBlocks = new HashSet();
                Set expansionAnchors = new HashSet();
                Integer oxygenY = null;
                if (maskClipboard != null) {
                    BlockVector3 maskTo = getCenteredPastePosition(chunk, maskClipboard, baseY);
                    if ("mask".equalsIgnoreCase(protectionMode) && markerMaterial != null) {
                        protectedBlocks = resolveProtectedBlocks(maskClipboard, maskTo, markerMaterial);
                        if (protectedBlocks.isEmpty()) {
                            plugin.getLogger().warning("Mask mode active but no protected blocks resolved. Fallback to shell protection.");
                        }
                    }
                    Material oxygenMarker = Material.matchMaterial(
                            plugin.getConfig().getString("oxygen.marker-material", "PURPLE_WOOL").toUpperCase(Locale.ROOT));
                    oxygenY = resolveOxygenY(maskClipboard, maskTo, oxygenMarker);
                    if (oxygenY == null) {
                        plugin.getLogger().warning("No oxygen markers found in mask, bunker will have no oxygen zone.");
                    }
                }
                plugin.getBunkerManager().addBunker(placement.worldName(), protectedBlocks, expansionAnchors,
                        placement.minX(), placement.minY(), placement.minZ(),
                        placement.maxX(), placement.maxY(), placement.maxZ(),
                        wallThickness, oxygenY, initialOxygen, player.getUniqueId());
                player.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.9f, 1.2f);
                send(player, "create-success");
                if (oxygenY != null) {
                    send(player, "oxygen-filled", ControlPanelMenu.mapOf("time", OxygenService.formatTime(initialOxygen)));
                }
            } catch (Exception e) {
                giveBackOrDrop(player, costs);
                send(player, "create-failed");
                send(player, "worldedit-error", ControlPanelMenu.mapOf("error", e.getMessage() != null ? e.getMessage() : "unknown"));
                plugin.getLogger().warning("Bunker paste failed: " + (e.getMessage() != null ? e.getMessage() : "unknown"));
            }
        }

        void stop(CancelReason reason) {
            cancelTask();
            sessions.remove(player.getUniqueId());
            if (!player.isOnline()) return;
            player.sendActionBar(Component.empty());
            giveBackOrDrop(player, costs);
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.9f, 0.7f);
            String key;
            switch (reason) {
                case SURFACE_CHANGED: key = "build-cancelled-surface"; break;
                case LEFT_CHUNK: key = "build-cancelled-left"; break;
                case MANUAL: key = "build-cancelled-manual"; break;
                default: key = "build-cancelled"; break;
            }
            send(player, key);
        }

        private void cancelTask() {
            if (task != null) {
                task.cancel();
                task = null;
            }
        }
    }
}

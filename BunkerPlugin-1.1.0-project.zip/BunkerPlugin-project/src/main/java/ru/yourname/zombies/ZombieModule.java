package ru.yourname.zombies;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.scheduler.BukkitTask;

/** Умные зомби: слух/зрение/запах, стая, прятки, спавн вокруг игроков. */
public final class ZombieModule implements Listener {

    private final ru.yourname.bunker.BunkerPlugin plugin;
    private final Map brains = new HashMap();        // UUID зомби -> ZombieBrain
    private final Map playerStates = new HashMap();  // UUID игрока -> PlayerStealth
    private final Map lastPlayerLoc = new HashMap(); // UUID игрока -> Location
    private FileConfiguration playersData;
    private File playersFile;
    private ZombieConfig zombieConfig;
    private final ZombieSpawner spawner;
    private BukkitTask tickTask;
    private int tickCounter; // увеличивается раз в секунду

    public ZombieModule(ru.yourname.bunker.BunkerPlugin plugin) {
        this.plugin = plugin;
        this.spawner = new ZombieSpawner(this);
    }

    public ru.yourname.bunker.BunkerPlugin getPlugin() {
        return this.plugin;
    }

    public ZombieConfig config() {
        return this.zombieConfig;
    }

    public void enable() {
        this.loadConfig();
        this.loadPlayersData();
        this.registerEvents();
        this.registerOnlinePlayers();
        this.registerExistingZombies();
        this.startTask();
    }

    public void disable() {
        if (this.tickTask != null) {
            this.tickTask.cancel();
            this.tickTask = null;
        }
        this.savePlayersData();
        this.brains.clear();
        this.playerStates.clear();
        this.lastPlayerLoc.clear();
    }

    public void reload() {
        if (this.tickTask != null) {
            this.tickTask.cancel();
            this.tickTask = null;
        }
        this.savePlayersData();
        this.loadConfig();
        this.loadPlayersData();
        this.registerOnlinePlayers();
        this.registerExistingZombies();
        this.startTask();
    }

    public void handleQuit(UUID playerId) {
        this.playerStates.remove(playerId);
        this.lastPlayerLoc.remove(playerId);
    }

    public void registerZombie(Zombie zombie) {
        if (zombie != null && zombie.isValid()) {
            this.brains.putIfAbsent(zombie.getUniqueId(), new ZombieBrain(zombie.getUniqueId()));
        }
    }

    public PlayerStealth stealth(UUID playerId) {
        return (PlayerStealth) this.playerStates.get(playerId);
    }

    private void startTask() {
        this.tickCounter = 0;
        this.tickTask = Bukkit.getScheduler().runTaskTimer((org.bukkit.plugin.Plugin) this.plugin, this::tick, 20L, 20L);
    }

    /** Основной тик (раз в секунду). */
    private void tick() {
        this.tickCounter = this.tickCounter + 1;
        this.spawner.bumpTick();
        this.updatePlayerStates();
        this.cleanupBrains();
        this.processNoiseHearing();
        this.processPerceptionAndStates();
        this.processPackChain();
        this.processHideProgress();
        this.spawner.tick();
        int saveInterval = Math.max(15, this.zombieConfig.newbieSaveIntervalSeconds());
        if (this.tickCounter % saveInterval == 0) {
            this.savePlayersData();
        }
    }

    /** Секунды newbie-защиты, дистанция движения за последний тик. */
    private void updatePlayerStates() {
        boolean newbieEnabled = this.zombieConfig.newbieEnabled();
        Iterator it = Bukkit.getOnlinePlayers().iterator();
        while (it.hasNext()) {
            Player player = (Player) it.next();
            UUID id = player.getUniqueId();
            PlayerStealth state = (PlayerStealth) this.playerStates.computeIfAbsent(id,
                    key -> new PlayerStealth((UUID) key, this.zombieConfig.newbieDurationSeconds()));
            Location current = player.getLocation();
            Location previous = (Location) this.lastPlayerLoc.get(id);
            state.movedDistance(previous == null || previous.getWorld() == null ? 0.0
                    : previous.getWorld().equals(current.getWorld()) ? Math.sqrt(previous.distanceSquared(current)) : 0.0);
            this.lastPlayerLoc.put(id, current.clone());
            if (!newbieEnabled || player.hasPermission("bunker.zombies.newbie.bypass")) {
                state.newbieProtectionLeft(0);
            } else if (state.newbieProtectionLeft() > 0) {
                state.newbieProtectionLeft(state.newbieProtectionLeft() - 1);
            }
        }
    }

    /** Импульсный слух: слышащих зомби ведёт к игроку (или они идут проверять). */
    private void processNoiseHearing() {
        int interval = this.zombieConfig.hearingImpulseSeconds();
        if (this.tickCounter % interval != 0) {
            return;
        }
        Iterator it = Bukkit.getOnlinePlayers().iterator();
        while (it.hasNext()) {
            Player player = (Player) it.next();
            if (!this.isSurfacePlayer(player) || !this.canDetectPlayer(player)) {
                continue;
            }
            PlayerStealth state = (PlayerStealth) this.playerStates.get(player.getUniqueId());
            if (state == null) {
                continue;
            }
            double radius = ZombiePerception.hearingRadius(player, state, this.zombieConfig);
            if (radius <= 0.0) {
                continue;
            }
            Iterator nearby = player.getWorld().getNearbyEntities(player.getLocation(), radius, 8.0, radius).iterator();
            while (nearby.hasNext()) {
                Entity entity = (Entity) nearby.next();
                if (!(entity instanceof Zombie)) {
                    continue;
                }
                Zombie zombie = (Zombie) entity;
                ZombieBrain brain = (ZombieBrain) this.brains.computeIfAbsent(zombie.getUniqueId(),
                        key -> new ZombieBrain((UUID) key));
                if (brain.state() == ZombieBrain.State.RETREAT || brain.hasTarget()) {
                    continue;
                }
                if (!ZombiePerception.canHear(zombie, player, state, this.zombieConfig)) {
                    continue;
                }
                boolean loud = player.isSprinting() || distance(zombie, player) <= Math.min(radius, 6.0);
                if (loud) {
                    this.alertZombie(zombie, brain, player);
                } else if (this.zombieConfig.investigateEnabled()) {
                    brain.investigateLocation(player.getLocation());
                    brain.investigateUntilTick(this.tickCounter + this.zombieConfig.investigateMaxSeconds());
                    brain.state(ZombieBrain.State.INVESTIGATE);
                }
            }
        }
    }

    /** Состояния зомби: погоня / отступление / маршруты. */
    private void processPerceptionAndStates() {
        Iterator it = new ArrayList(this.brains.values()).iterator();
        while (it.hasNext()) {
            ZombieBrain brain = (ZombieBrain) it.next();
            Zombie zombie = this.getZombie(brain.zombieId());
            if (zombie == null || zombie.isDead() || !zombie.isValid()) {
                this.brains.remove(brain.zombieId());
                continue;
            }
            if (brain.state() == ZombieBrain.State.RETREAT) {
                this.processRetreat(zombie, brain);
                continue;
            }
            Player target = this.resolveTarget(brain);
            if (target == null) {
                if (brain.hasTarget()) {
                    brain.clearTarget();
                    brain.state(ZombieBrain.State.IDLE);
                    zombie.setTarget((LivingEntity) null);
                }
                this.detectAndAlert(zombie, brain);
                this.updateRouting(zombie, brain);
            } else {
                this.processChase(zombie, brain, target);
            }
        }
    }

    /** Ближайший видимый/чуемый игрок. */
    private void detectAndAlert(Zombie zombie, ZombieBrain brain) {
        Player best = null;
        double bestDistance = Double.MAX_VALUE;
        Iterator it = Bukkit.getOnlinePlayers().iterator();
        while (it.hasNext()) {
            Player player = (Player) it.next();
            if (!this.isSurfacePlayer(player) || !this.canDetectPlayer(player)) {
                continue;
            }
            double distance;
            if (ZombiePerception.canSee(zombie, player, this.zombieConfig)) {
                distance = distance(zombie, player);
            } else if (ZombiePerception.canSmell(zombie, player, this.zombieConfig)) {
                distance = distance(zombie, player);
            } else {
                continue;
            }
            if (distance < bestDistance) {
                bestDistance = distance;
                best = player;
            }
        }
        if (best != null) {
            this.alertZombie(zombie, brain, best);
        }
    }

    private void processChase(Zombie zombie, ZombieBrain brain, Player target) {
        brain.state(ZombieBrain.State.CHASE);
        brain.targetPlayerId(target.getUniqueId());
        if (distance(zombie, target) > this.zombieConfig.targetLoseDistance()) {
            this.startSearchAtLastSeen(brain);
            return;
        }
        if (ZombiePerception.canSee(zombie, target, this.zombieConfig)) {
            brain.lastSeenLocation(target.getLocation(), this.tickCounter);
            brain.lostTicks(0);
        } else {
            brain.lostTicks(brain.lostTicks() + 1);
            if (brain.lostTicks() >= this.zombieConfig.searchLastSeenSeconds()) {
                this.startSearchAtLastSeen(brain);
                return;
            }
        }
        zombie.setTarget((LivingEntity) target);
        ZombieSteering.moveTowards(zombie, target.getLocation(), this.zombieConfig.retreatSpeed());
    }

    private Player resolveTarget(ZombieBrain brain) {
        if (!brain.hasTarget()) {
            return null;
        }
        Player player = Bukkit.getPlayer(brain.targetPlayerId());
        if (player != null && player.isOnline() && this.isSurfacePlayer(player) && this.canDetectPlayer(player)) {
            return player;
        }
        return null;
    }

    /** Маршруты без цели: расследование -> поиск -> блуждание. */
    private void updateRouting(Zombie zombie, ZombieBrain brain) {
        if (brain.investigateLocation() != null) {
            brain.state(ZombieBrain.State.INVESTIGATE);
            if (this.tickCounter > brain.investigateUntilTick()) {
                brain.investigateLocation(null);
                brain.state(ZombieBrain.State.IDLE);
            } else if (this.arrive(zombie, brain.investigateLocation())) {
                brain.investigateLocation(null);
                brain.state(ZombieBrain.State.IDLE);
            } else {
                ZombieSteering.moveTowards(zombie, brain.investigateLocation(), this.zombieConfig.investigateSpeed());
            }
            return;
        }
        if (brain.searchLocation() != null) {
            brain.state(ZombieBrain.State.SEARCH);
            if (this.tickCounter > brain.searchUntilTick()) {
                brain.searchLocation(null);
                brain.state(ZombieBrain.State.IDLE);
            } else if (this.arrive(zombie, brain.searchLocation())) {
                brain.searchLocation(null);
                brain.state(ZombieBrain.State.IDLE);
            } else {
                ZombieSteering.moveTowards(zombie, brain.searchLocation(), this.zombieConfig.wanderSpeed());
            }
            return;
        }
        if (!this.zombieConfig.wanderEnabled()) {
            brain.state(ZombieBrain.State.IDLE);
            return;
        }
        if (brain.wanderTarget() == null || brain.wanderCooldownTicks() <= 0) {
            Location current = zombie.getLocation();
            double angle = java.util.concurrent.ThreadLocalRandom.current().nextDouble(0.0, Math.PI * 2);
            double radius = this.zombieConfig.wanderRadius();
            int x = current.getBlockX() + (int) Math.round(Math.cos(angle) * radius);
            int z = current.getBlockZ() + (int) Math.round(Math.sin(angle) * radius);
            int y = current.getWorld().getHighestBlockYAt(x, z) + 1;
            brain.wanderTarget(new Location(current.getWorld(), x + 0.5, y, z + 0.5));
            brain.wanderCooldownTicks(this.zombieConfig.wanderIntervalTicks());
        } else {
            brain.wanderCooldownTicks(brain.wanderCooldownTicks() - 1);
        }
        brain.state(ZombieBrain.State.WANDER);
        if (this.arrive(zombie, brain.wanderTarget())) {
            brain.wanderTarget(null);
            brain.state(ZombieBrain.State.IDLE);
        } else {
            ZombieSteering.moveTowards(zombie, brain.wanderTarget(), this.zombieConfig.wanderSpeed());
        }
    }

    private void startSearchAtLastSeen(ZombieBrain brain) {
        if (brain.lastSeenLocation() == null) {
            brain.resetRouting();
            brain.clearTarget();
            brain.state(ZombieBrain.State.IDLE);
        } else {
            brain.resetRouting();
            brain.clearTarget();
            brain.searchLocation(brain.lastSeenLocation());
            brain.searchUntilTick(this.tickCounter + this.zombieConfig.searchLastSeenSeconds());
            brain.state(ZombieBrain.State.SEARCH);
        }
    }

    /** Стая: преследователи зовут соседей, но не больше max-pack-size. */
    private void processPackChain() {
        if (!this.zombieConfig.packEnabled() || !this.zombieConfig.packChainAlert()) {
            return;
        }
        List chasers = new ArrayList();
        Iterator it = this.brains.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            ZombieBrain brain = (ZombieBrain) entry.getValue();
            if (brain.state() == ZombieBrain.State.CHASE && brain.hasTarget()) {
                chasers.add(entry);
            }
        }
        double chainRadius = this.zombieConfig.packChainRadius();
        int maxSize = this.zombieConfig.packMaxSize();
        Iterator chaserIt = chasers.iterator();
        while (chaserIt.hasNext()) {
            Map.Entry entry = (Map.Entry) chaserIt.next();
            Zombie zombie = this.getZombie((UUID) entry.getKey());
            if (zombie == null) {
                continue;
            }
            UUID targetId = ((ZombieBrain) entry.getValue()).targetPlayerId();
            int pursuers = this.countPursuers(targetId);
            Iterator nearby = zombie.getWorld().getNearbyEntities(zombie.getLocation(), chainRadius, 8.0, chainRadius).iterator();
            while (nearby.hasNext() && pursuers < maxSize) {
                Entity entity = (Entity) nearby.next();
                if (!(entity instanceof Zombie)) {
                    continue;
                }
                Zombie other = (Zombie) entity;
                ZombieBrain otherBrain = (ZombieBrain) this.brains.get(other.getUniqueId());
                if (otherBrain == null || otherBrain.hasTarget() || otherBrain.state() == ZombieBrain.State.RETREAT) {
                    continue;
                }
                Player target = Bukkit.getPlayer(targetId);
                if (target != null && target.isOnline()) {
                    this.alertZombie(other, otherBrain, target);
                    pursuers = pursuers + 1;
                }
            }
        }
    }

    private int countPursuers(UUID playerId) {
        int count = 0;
        Iterator it = this.brains.values().iterator();
        while (it.hasNext()) {
            ZombieBrain brain = (ZombieBrain) it.next();
            if (brain.state() == ZombieBrain.State.CHASE && playerId.equals(brain.targetPlayerId())) {
                count = count + 1;
            }
        }
        return count;
    }

    /** Прогресс "затишья": игрок тихо сидит в укрытии -> зомби отступают. */
    private void processHideProgress() {
        int required = this.zombieConfig.hiddenProgressSeconds();
        int resetPerSecond = this.zombieConfig.hiddenProgressResetPerSecond();
        double minDistance = this.zombieConfig.hiddenMinDistance();
        double maxSneakMove = this.zombieConfig.hiddenMaxSneakMove();
        boolean requiresNoLineOfSight = this.zombieConfig.hiddenRequiresNoLineOfSight();
        boolean requiresAllNoLineOfSight = this.zombieConfig.hiddenRequiresAllNoLineOfSight();
        Iterator it = Bukkit.getOnlinePlayers().iterator();
        while (it.hasNext()) {
            Player player = (Player) it.next();
            if (!this.isSurfacePlayer(player)) {
                continue;
            }
            PlayerStealth state = (PlayerStealth) this.playerStates.computeIfAbsent(player.getUniqueId(),
                    key -> new PlayerStealth((UUID) key, this.zombieConfig.newbieDurationSeconds()));
            if (this.plugin.isPlayerBuilding(player.getUniqueId())) {
                this.clearHideProgressBar(player, state);
                continue;
            }
            List pursuers = this.getPursuers(player);
            if (pursuers.isEmpty()) {
                this.clearHideProgressBar(player, state);
                continue;
            }
            boolean quiet = player.isSneaking() && state.movedDistance() <= maxSneakMove;
            boolean allFar = true;
            boolean anyNoLineOfSight = false;
            boolean allNoLineOfSight = true;
            Iterator pursuerIt = pursuers.iterator();
            while (pursuerIt.hasNext()) {
                ZombieRef ref = (ZombieRef) pursuerIt.next();
                if (ref.zombie().getLocation().distance(player.getLocation()) < minDistance) {
                    allFar = false;
                }
                boolean noLineOfSight = !ref.zombie().hasLineOfSight((Entity) player);
                anyNoLineOfSight = anyNoLineOfSight || noLineOfSight;
                allNoLineOfSight = allNoLineOfSight && noLineOfSight;
            }
            boolean hidden;
            if (!requiresNoLineOfSight) {
                hidden = true;
            } else if (requiresAllNoLineOfSight) {
                hidden = allNoLineOfSight;
            } else {
                hidden = anyNoLineOfSight;
            }
            boolean progressing = quiet && allFar && hidden;
            if (progressing) {
                state.hideProgressSeconds(Math.min(required, state.hideProgressSeconds() + 1));
            } else {
                state.hideProgressSeconds(Math.max(0, state.hideProgressSeconds() - resetPerSecond));
            }
            if (state.hideProgressSeconds() <= 0) {
                this.clearHideProgressBar(player, state);
                continue;
            }
            this.showHideProgressBar(player, state.hideProgressSeconds(), required);
            state.hideBarVisible(true);
            if (state.hideProgressSeconds() >= required) {
                state.hideProgressSeconds(0);
                state.escapeCooldownUntilTick(this.tickCounter + this.zombieConfig.escapeCooldownSeconds());
                this.clearHideProgressBar(player, state);
                Iterator retreatIt = pursuers.iterator();
                while (retreatIt.hasNext()) {
                    ZombieRef ref = (ZombieRef) retreatIt.next();
                    this.startRetreat(ref.zombie(), ref.brain(), player.getLocation());
                }
            }
        }
    }

    private List getPursuers(Player player) {
        List pursuers = new ArrayList();
        UUID playerId = player.getUniqueId();
        Iterator it = this.brains.values().iterator();
        while (it.hasNext()) {
            ZombieBrain brain = (ZombieBrain) it.next();
            if (brain.state() == ZombieBrain.State.CHASE && playerId.equals(brain.targetPlayerId())) {
                Zombie zombie = this.getZombie(brain.zombieId());
                if (zombie != null && zombie.isValid() && !zombie.isDead()) {
                    pursuers.add(new ZombieRef(zombie, brain));
                }
            }
        }
        return pursuers;
    }

    private void alertZombie(Zombie zombie, ZombieBrain brain, Player player) {
        brain.resetRouting();
        brain.targetPlayerId(player.getUniqueId());
        brain.lastSeenLocation(player.getLocation(), this.tickCounter);
        brain.state(ZombieBrain.State.CHASE);
        zombie.setTarget((LivingEntity) player);
    }

    private void startRetreat(Zombie zombie, ZombieBrain brain, Location from) {
        brain.resetRouting();
        brain.clearTarget();
        brain.state(ZombieBrain.State.RETREAT);
        brain.retreatOrigin(from.clone());
        brain.retreatUntilTick(this.tickCounter + this.zombieConfig.retreatMaxSeconds());
        zombie.setTarget((LivingEntity) null);
        this.processRetreat(zombie, brain);
    }

    private void processRetreat(Zombie zombie, ZombieBrain brain) {
        Location origin = brain.retreatOrigin();
        if (origin != null && sameWorld(zombie.getLocation(), origin)) {
            if (this.tickCounter > brain.retreatUntilTick()) {
                brain.state(ZombieBrain.State.IDLE);
                brain.retreatOrigin(null);
                return;
            }
            if (zombie.getLocation().distance(origin) < this.zombieConfig.retreatDistance()) {
                ZombieSteering.fleeFrom(zombie, origin, this.zombieConfig.retreatSpeed());
                return;
            }
            brain.state(ZombieBrain.State.IDLE);
            brain.retreatOrigin(null);
            ZombieSteering.stop(zombie);
            return;
        }
        brain.state(ZombieBrain.State.IDLE);
    }

    private boolean canDetectPlayer(Player player) {
        PlayerStealth state = (PlayerStealth) this.playerStates.get(player.getUniqueId());
        return state == null || this.tickCounter >= state.escapeCooldownUntilTick();
    }

    public boolean isSurfacePlayer(Player player) {
        return player != null && player.isOnline()
                && this.plugin.getBunkerManager().getBunkerAt(player.getLocation()) == null;
    }

    public boolean isDay(World world) {
        long time = world.getTime();
        return time < 12300L || time > 23850L;
    }

    public int countTrackedZombies() {
        this.cleanupBrains();
        return this.brains.size();
    }

    public int countTrackedZombiesNear(Location location, double radius) {
        double squared = radius * radius;
        int count = 0;
        Iterator it = new ArrayList(this.brains.keySet()).iterator();
        while (it.hasNext()) {
            UUID id = (UUID) it.next();
            Zombie zombie = this.getZombie(id);
            if (zombie == null || zombie.isDead() || !zombie.isValid()) {
                this.brains.remove(id);
                continue;
            }
            if (!sameWorld(zombie.getLocation(), location)) {
                continue;
            }
            if (zombie.getLocation().distanceSquared(location) <= squared) {
                count = count + 1;
            }
        }
        return count;
    }

    private void cleanupBrains() {
        Iterator it = this.brains.keySet().iterator();
        while (it.hasNext()) {
            Zombie zombie = this.getZombie((UUID) it.next());
            if (zombie == null || zombie.isDead() || !zombie.isValid()) {
                it.remove();
            }
        }
    }

    private Zombie getZombie(UUID id) {
        Entity entity = Bukkit.getEntity(id);
        return entity instanceof Zombie ? (Zombie) entity : null;
    }

    /** Полоса прогресса "Тишина" в актионбаре. */
    private void showHideProgressBar(Player player, int progress, int required) {
        int length = this.zombieConfig.hiddenProgressBarLength();
        int filled = Math.max(0, Math.min(Math.round((float) length * ((float) progress / (float) required)), length));
        Component bar = Component.empty();
        for (int i = 0; i < length; i++) {
            Component segment = i < filled
                    ? Component.text("\u2588").color(TextColor.color(54927425))
                    : Component.text("\u2591").color(TextColor.color(3818054));
            bar = bar.append(segment);
        }
        int secondsLeft = Math.max(0, required - progress);
        player.sendActionBar(Component.empty().decoration(TextDecoration.ITALIC, false)
                .append(Component.text("Тишина ").color(TextColor.color(14870768)))
                .append(bar)
                .append(Component.text(" " + secondsLeft + "с").color(TextColor.color(14870768))));
    }

    private void clearHideProgressBar(Player player, PlayerStealth state) {
        if (state.hideBarVisible()) {
            player.sendActionBar(Component.empty());
            state.hideBarVisible(false);
        }
    }

    private boolean arrive(Zombie zombie, Location target) {
        return target != null && sameWorld(zombie.getLocation(), target)
                && zombie.getLocation().distanceSquared(target) < 1.96;
    }

    private static double distance(Zombie zombie, Player player) {
        return zombie.getLocation().distance(player.getLocation());
    }

    private static boolean sameWorld(Location a, Location b) {
        return a != null && b != null && a.getWorld() != null && a.getWorld().equals(b.getWorld());
    }

    // ------------------------------------------------------------------
    // События
    // ------------------------------------------------------------------

    @EventHandler
    public void onZombieSpawn(CreatureSpawnEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity instanceof Zombie) {
            this.registerZombie((Zombie) entity);
        }
    }

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent event) {
        Chunk chunk = event.getChunk();
        Entity[] entities = chunk.getEntities();
        for (int i = 0; i < entities.length; i++) {
            if (entities[i] instanceof Zombie) {
                this.registerZombie((Zombie) entities[i]);
            }
        }
    }

    @EventHandler
    public void onZombieDeath(EntityDeathEvent event) {
        this.brains.remove(event.getEntity().getUniqueId());
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        this.initPlayerState(event.getPlayer());
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        this.handleQuit(event.getPlayer().getUniqueId());
    }

    private void registerEvents() {
        this.plugin.getServer().getPluginManager().registerEvents((Listener) this, (org.bukkit.plugin.Plugin) this.plugin);
    }

    private void registerOnlinePlayers() {
        Iterator it = Bukkit.getOnlinePlayers().iterator();
        while (it.hasNext()) {
            this.initPlayerState((Player) it.next());
        }
    }

    private void initPlayerState(Player player) {
        UUID id = player.getUniqueId();
        if (!this.playerStates.containsKey(id)) {
            this.playerStates.put(id, new PlayerStealth(id, this.zombieConfig.newbieDurationSeconds()));
        }
        this.lastPlayerLoc.put(id, player.getLocation().clone());
    }

    private void registerExistingZombies() {
        this.brains.clear();
        Iterator worlds = Bukkit.getWorlds().iterator();
        while (worlds.hasNext()) {
            World world = (World) worlds.next();
            Iterator zombies = world.getEntitiesByClass(Zombie.class).iterator();
            while (zombies.hasNext()) {
                this.registerZombie((Zombie) zombies.next());
            }
        }
    }

    private void loadConfig() {
        File file = new File(this.plugin.getDataFolder(), "zombies.yml");
        if (!file.exists()) {
            this.plugin.saveResource("zombies.yml", false);
        }
        FileConfiguration config = YamlConfiguration.loadConfiguration(file);
        this.zombieConfig = new ZombieConfig(config);
        this.spawner.reload();
    }

    private void loadPlayersData() {
        if (!this.plugin.getDataFolder().exists()) {
            this.plugin.getDataFolder().mkdirs();
        }
        this.playersFile = new File(this.plugin.getDataFolder(), "players.yml");
        if (!this.playersFile.exists()) {
            this.plugin.saveResource("players.yml", false);
        }
        this.playersData = YamlConfiguration.loadConfiguration(this.playersFile);
        this.playerStates.clear();
        ConfigurationSection section = this.playersData.getConfigurationSection("players");
        if (section == null) {
            return;
        }
        Iterator it = section.getKeys(false).iterator();
        while (it.hasNext()) {
            String key = (String) it.next();
            try {
                UUID id = UUID.fromString(key);
                int left = Math.max(0, this.playersData.getInt("players." + key, 0));
                this.playerStates.put(id, new PlayerStealth(id, left));
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    private void savePlayersData() {
        if (this.playersData == null || this.playersFile == null) {
            return;
        }
        this.playersData.set("players", null);
        Iterator it = this.playerStates.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            this.playersData.set("players." + entry.getKey(),
                    Integer.valueOf(((PlayerStealth) entry.getValue()).newbieProtectionLeft()));
        }
        try {
            this.playersData.save(this.playersFile);
        } catch (IOException e) {
            this.plugin.getLogger().warning("Не удалось сохранить players.yml: " + e.getMessage());
        }
    }

    /** Пара зомби+мозг для списка преследователей. */
    static final class ZombieRef {
        private final Zombie zombie;
        private final ZombieBrain brain;

        ZombieRef(Zombie zombie, ZombieBrain brain) {
            this.zombie = zombie;
            this.brain = brain;
        }

        Zombie zombie() {
            return this.zombie;
        }

        ZombieBrain brain() {
            return this.brain;
        }
    }
}

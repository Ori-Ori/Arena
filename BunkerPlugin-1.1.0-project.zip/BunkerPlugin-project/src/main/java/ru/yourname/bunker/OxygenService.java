package ru.yourname.bunker;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

/** Кислород: тик раз в секунду, дыхание игроков, удушье, актионбар, автосохранение. */
public final class OxygenService {

    /** Личное состояние дыхания игрока. */
    static final class PlayerBreath {
        int breathSeconds;
        int suffocatingSeconds;
        PlayerBreath(int breathSeconds) { this.breathSeconds = breathSeconds; }
    }

    private final BunkerPlugin plugin;
    private final Map breathByPlayer = new HashMap(); // Map<UUID, PlayerBreath>
    private BukkitTask task;
    private int saveCounter;

    public OxygenService(BunkerPlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        stop();
        task = Bukkit.getScheduler().runTaskTimer(plugin, (Runnable) () -> tick(), 20L, 20L);
    }

    public void stop() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }

    public void handleQuit(UUID uuid) {
        breathByPlayer.remove(uuid);
    }

    public int getBreathSeconds(Player player) {
        PlayerBreath breath = (PlayerBreath) breathByPlayer.get(player.getUniqueId());
        return breath != null ? breath.breathSeconds : getMaxBreathSeconds();
    }

    public int getMaxBreathSeconds() {
        return Math.max(1, plugin.getConfig().getInt("oxygen.breath-hold-seconds", 120));
    }

    private void tick() {
        BunkerManager manager = plugin.getBunkerManager();
        if (manager == null) return;

        Map occupied = new HashMap(); // Map<bunkerId, Boolean есть ли живые игроки в зоне>
        Iterator it = Bukkit.getOnlinePlayers().iterator();
        while (it.hasNext()) {
            Player player = (Player) it.next();
            ProtectedBunker zone = manager.getOxygenZoneAt(player.getLocation());
            PlayerBreath breath = (PlayerBreath) breathByPlayer.computeIfAbsent(player.getUniqueId(),
                    uuid -> new PlayerBreath(getMaxBreathSeconds()));
            boolean bypass = player.getGameMode() == GameMode.CREATIVE
                    || player.getGameMode() == GameMode.SPECTATOR
                    || player.hasPermission("bunker.oxygen.bypass");
            if (zone != null) {
                if (!bypass) occupied.put(zone.id(), Boolean.TRUE);
                if (zone.hasOxygen()) {
                    refillBreath(breath);
                    breath.suffocatingSeconds = 0;
                    sendOxygenBar(player, zone, breath, true);
                } else if (!bypass) {
                    if (breath.breathSeconds <= 0) {
                        breath.suffocatingSeconds++;
                        applySuffocation(player, breath);
                        sendOxygenBar(player, zone, breath, false);
                    } else {
                        breath.breathSeconds--;
                        breath.suffocatingSeconds = 0;
                        sendOxygenBar(player, zone, breath, false);
                    }
                }
            } else {
                // снаружи бункера дыхание восстанавливается
                refillBreath(breath);
                breath.suffocatingSeconds = 0;
            }
        }

        // кислород бункера тратится, только если внутри реально кто-то есть
        Iterator bunkerIt = manager.getBunkers().iterator();
        while (bunkerIt.hasNext()) {
            ProtectedBunker bunker = (ProtectedBunker) bunkerIt.next();
            if (bunker.hasOxygenZone() && bunker.hasOxygen() && occupied.containsKey(bunker.id())) {
                bunker.consumeOxygen(1);
            }
        }

        saveCounter++;
        int saveInterval = Math.max(10, plugin.getConfig().getInt("oxygen.save-interval-seconds", 60));
        if (saveCounter >= saveInterval) {
            saveCounter = 0;
            manager.saveOxygenState();
        }
    }

    private void refillBreath(PlayerBreath breath) {
        int max = getMaxBreathSeconds();
        int refill = Math.max(1, plugin.getConfig().getInt("oxygen.breath-refill-per-second", 4));
        breath.breathSeconds = Math.min(max, breath.breathSeconds + refill);
    }

    private void applySuffocation(Player player, PlayerBreath breath) {
        int nauseaAfter = Math.max(0, plugin.getConfig().getInt("oxygen.nausea-after-seconds", 0));
        int damageAfter = Math.max(1, plugin.getConfig().getInt("oxygen.damage-after-seconds", 60));
        int damageInterval = Math.max(1, plugin.getConfig().getInt("oxygen.damage-interval-seconds", 10));
        double base = plugin.getConfig().getDouble("oxygen.damage-base", 1.0);
        double perMinute = plugin.getConfig().getDouble("oxygen.damage-increase-per-minute", 1.0);
        double max = plugin.getConfig().getDouble("oxygen.damage-max", 6.0);

        if (breath.suffocatingSeconds >= nauseaAfter && breath.suffocatingSeconds % 5 == 0) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 160, 0, true, false, false));
        }
        if (breath.suffocatingSeconds < damageAfter) return;
        int over = breath.suffocatingSeconds - damageAfter;
        if (over % damageInterval != 0) return;
        player.damage(Math.min(max, base + (over / 60) * perMinute));
    }

    private void sendOxygenBar(Player player, ProtectedBunker bunker, PlayerBreath breath, boolean hasOxygen) {
        if (!plugin.getConfig().getBoolean("oxygen.action-bar", true)) return;
        if (plugin.isPlayerBuilding(player.getUniqueId())) return; // не перебиваем прогресс-бар стройки

        Component bar;
        if (hasOxygen) {
            int left = bunker.oxygenSeconds();
            TextColor color = left <= 60 ? TextColor.color(15680580)
                    : left <= 300 ? TextColor.color(16436245)
                    : TextColor.color(3462008);
            bar = Component.empty().decoration(TextDecoration.ITALIC, false)
                    .append(Component.text("\u2601 Кислород: ").color(TextColor.color(14870768)))
                    .append(Component.text(formatTime(bunker.oxygenSeconds()) + " / " + formatTime(bunker.maxOxygenSeconds())).color(color));
        } else if (breath.breathSeconds <= 0) {
            bar = Component.empty().decoration(TextDecoration.ITALIC, false)
                    .append(Component.text("\u2620 Вы задыхаетесь! Срочно наверх!").color(TextColor.color(15680580))
                            .decoration(TextDecoration.BOLD, true));
        } else {
            bar = Component.empty().decoration(TextDecoration.ITALIC, false)
                    .append(Component.text("\u2620 Кислорода нет! Задержка дыхания: ").color(TextColor.color(15680580)))
                    .append(Component.text(formatTime(breath.breathSeconds)).color(TextColor.color(16436245)));
        }
        player.sendActionBar(bar);
    }

    /** 125 -> "02:05". */
    public static String formatTime(int seconds) {
        int s = Math.max(0, seconds);
        return String.format("%02d:%02d", new Object[]{Integer.valueOf(s / 60), Integer.valueOf(s % 60)});
    }
}

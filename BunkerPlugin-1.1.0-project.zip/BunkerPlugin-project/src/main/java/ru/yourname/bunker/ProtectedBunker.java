package ru.yourname.bunker;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;

/** Построенный бункер: границы, защищённые блоки, кислородная зона. */
public final class ProtectedBunker {

    private final String id;
    private final String worldName;
    private final Set protectedBlocks;      // Set<Long>, координаты упакованы через encode()
    private Set expansionAnchors;           // Set<Long>
    private final int minX, minY, minZ, maxX, maxY, maxZ;
    private final int wallThickness;
    private final Integer oxygenY;          // ниже этого Y — кислородная зона (null = зоны нет)
    private int oxygenSeconds;              // остаток кислорода бункера
    private int maxOxygenSeconds;

    public ProtectedBunker(String id, String worldName, Set protectedBlocks, Set expansionAnchors,
                           int minX, int minY, int minZ, int maxX, int maxY, int maxZ,
                           int wallThickness, Integer oxygenY, int oxygenSeconds, int maxOxygenSeconds) {
        this.id = id;
        this.worldName = worldName;
        this.protectedBlocks = protectedBlocks != null ? new HashSet(protectedBlocks) : new HashSet();
        this.expansionAnchors = expansionAnchors != null ? new HashSet(expansionAnchors) : new HashSet();
        this.minX = minX; this.minY = minY; this.minZ = minZ;
        this.maxX = maxX; this.maxY = maxY; this.maxZ = maxZ;
        this.wallThickness = Math.max(1, wallThickness);
        this.oxygenY = oxygenY;
        this.maxOxygenSeconds = Math.max(0, maxOxygenSeconds);
        this.oxygenSeconds = Math.max(0, Math.min(oxygenSeconds, this.maxOxygenSeconds));
    }

    public String id() { return id; }
    public String worldName() { return worldName; }
    public Set protectedBlocks() { return protectedBlocks; }
    public Set expansionAnchors() { return expansionAnchors; }
    public boolean hasExpansionAnchors() { return !expansionAnchors.isEmpty(); }
    public void setExpansionAnchors(Set anchors) {
        this.expansionAnchors = anchors != null ? new HashSet((Collection) anchors) : new HashSet();
    }
    public int minX() { return minX; }
    public int minY() { return minY; }
    public int minZ() { return minZ; }
    public int maxX() { return maxX; }
    public int maxY() { return maxY; }
    public int maxZ() { return maxZ; }
    public int wallThickness() { return wallThickness; }
    public Integer oxygenY() { return oxygenY; }
    public boolean hasOxygenZone() { return oxygenY != null; }
    public int oxygenSeconds() { return oxygenSeconds; }
    public int maxOxygenSeconds() { return maxOxygenSeconds; }
    public boolean hasOxygen() { return oxygenSeconds > 0; }
    public void setMaxOxygenSeconds(int seconds) {
        this.maxOxygenSeconds = Math.max(0, seconds);
        if (this.oxygenSeconds > this.maxOxygenSeconds) this.oxygenSeconds = this.maxOxygenSeconds;
    }

    /** Списать кислород (в секундах). true — если списание прошло. */
    public boolean consumeOxygen(int seconds) {
        if (oxygenSeconds <= 0) return false;
        oxygenSeconds = Math.max(0, oxygenSeconds - seconds);
        return true;
    }

    public void addOxygen(int seconds) {
        oxygenSeconds = Math.min(maxOxygenSeconds, Math.max(0, oxygenSeconds + seconds));
    }

    public void setOxygenSeconds(int seconds) {
        this.oxygenSeconds = Math.max(0, Math.min(seconds, maxOxygenSeconds));
    }

    public boolean isSameWorld(World world) {
        return world != null && world.getName().equalsIgnoreCase(worldName);
    }

    /** Находится ли точка внутри габаритов бункера. */
    public boolean containsLocation(Location loc) {
        return loc != null && isSameWorld(loc.getWorld())
                && loc.getBlockX() >= minX && loc.getBlockX() <= maxX
                && loc.getBlockZ() >= minZ && loc.getBlockZ() <= maxZ
                && loc.getBlockY() >= minY && loc.getBlockY() <= maxY;
    }

    /** Находится ли точка в кислородной зоне (внутри бункера и ниже oxygenY). */
    public boolean isInOxygenZone(Location loc) {
        return hasOxygenZone() && containsLocation(loc) && loc.getBlockY() < oxygenY.intValue();
    }

    /**
     * Защищён ли блок.
     * mask-режим: блок есть в наборе защищённых (маркеры ORANGE_WOOL из маск-схемы).
     * shell-режим (набор пуст): блок в габаритах, но не во внутренней коробке (стены/пол/потолок).
     */
    public boolean isProtected(Block block) {
        if (!protectedBlocks.isEmpty()) {
            return protectedBlocks.contains(Long.valueOf(encode(block.getX(), block.getY(), block.getZ())));
        }
        boolean inside = block.getX() >= minX && block.getX() <= maxX
                && block.getY() >= minY && block.getY() <= maxY
                && block.getZ() >= minZ && block.getZ() <= maxZ;
        if (!inside) return false;
        int innerMinX = minX + wallThickness, innerMinY = minY + wallThickness, innerMinZ = minZ + wallThickness;
        int innerMaxX = maxX - wallThickness, innerMaxY = maxY - wallThickness, innerMaxZ = maxZ - wallThickness;
        if (innerMinX > innerMaxX || innerMinY > innerMaxY || innerMinZ > innerMaxZ) {
            return true; // бункер меньше толщины стен — защищаем всё
        }
        boolean inInner = block.getX() >= innerMinX && block.getX() <= innerMaxX
                && block.getY() >= innerMinY && block.getY() <= innerMaxY
                && block.getZ() >= innerMinZ && block.getZ() <= innerMaxZ;
        return !inInner;
    }

    /** Упаковка координат в long: 26 бит X | 26 бит Z | 12 бит Y (как в Minecraft). */
    public static long encode(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (long) (y & 0xFFF);
    }
}

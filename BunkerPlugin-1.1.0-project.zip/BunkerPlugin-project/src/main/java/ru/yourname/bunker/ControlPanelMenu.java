package ru.yourname.bunker;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/** GUI 3x3: сетка чанков бункера. Красная шерсть — можно купить, зелёная — куплено. */
public final class ControlPanelMenu implements InventoryHolder {

    /** Смещения чанков сетки 3x3 (порядок важен, соответствует GRID_SLOTS). */
    private static final int[][] REL = {
            {-1, -1}, {0, -1}, {1, -1},
            {-1, 0}, {0, 0}, {1, 0},
            {-1, 1}, {0, 1}, {1, 1}
    };
    /** Слоты инвентаря 27, образующие сетку 3x3 (с отступами). */
    private static final int[] GRID_SLOTS = {3, 4, 5, 12, 13, 14, 21, 22, 23};

    private final BunkerPlugin plugin;
    private final Player player;
    private final BunkerClaim claim;
    private final Inventory inventory;

    public ControlPanelMenu(BunkerPlugin plugin, Player player, BunkerClaim claim) {
        this.plugin = plugin;
        this.player = player;
        this.claim = claim;
        this.inventory = Bukkit.createInventory(this, 27, color("&6&lУправление бункером"));
        buildItems();
    }

    public static void open(BunkerPlugin plugin, Player player, BunkerClaim claim) {
        player.openInventory(new ControlPanelMenu(plugin, player, claim).getInventory());
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    private void buildItems() {
        for (int i = 0; i < 9; i++) {
            int dx = REL[i][0];
            int dz = REL[i][1];
            ChunkKey chunkKey = claim.chunkAt(dx, dz);
            if (dx == 0 && dz == 0) {
                inventory.setItem(GRID_SLOTS[i], buildCenterItem());
            } else if (claim.isChunkOwned(chunkKey)) {
                inventory.setItem(GRID_SLOTS[i], buildOwnedItem(chunkKey));
            } else {
                inventory.setItem(GRID_SLOTS[i], buildForSaleItem(chunkKey));
            }
        }
    }

    private ItemStack buildCenterItem() {
        ItemStack item = new ItemStack(Material.NETHER_STAR);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(color("&bЦентр бункера"));
        List lore = new ArrayList();
        lore.add(color("&7Координаты: &f" + claim.centerChunkX() + ", " + claim.centerChunkZ()));
        lore.add(color("&7Глава: &f" + nameOf(claim.owner())));
        lore.add(color("&7Заместители: &f" + namesOf(claim.deputies())));
        lore.add(color("&7Участников: &f" + (claim.members().size() + 1)));
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack buildForSaleItem(ChunkKey chunkKey) {
        ItemStack item = new ItemStack(Material.RED_WOOL);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(color("&cЧанк не куплен"));
        List lore = new ArrayList();
        lore.add(color("&7Координаты: &f" + chunkKey.chunkX() + ", " + chunkKey.chunkZ()));
        lore.add(color("&7Цена покупки:"));
        Iterator it = plugin.getClaimManager().getCost().entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            lore.add(color("&f  " + ((Integer) entry.getValue()).intValue() + " x"
                    + plugin.getClaimManager().materialDisplayName((org.bukkit.Material) entry.getKey())));
        }
        if (claim.isMember(player.getUniqueId())) {
            lore.add(color("&aНажмите, чтобы купить."));
        } else {
            lore.add(color("&cНужно состоять в бункере."));
        }
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack buildOwnedItem(ChunkKey chunkKey) {
        ItemStack item = new ItemStack(Material.GREEN_WOOL);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(color("&aЧанк куплен"));
        List lore = new ArrayList();
        lore.add(color("&7Координаты: &f" + chunkKey.chunkX() + ", " + chunkKey.chunkZ()));
        lore.add(color("&7Строить могут только участники бункера."));
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    public void onClick(InventoryClickEvent event) {
        event.setCancelled(true);
        if (event.getWhoClicked() != player) return;
        ItemStack current = event.getCurrentItem();
        if (current == null || current.getType() == Material.AIR || current.getType() == Material.NETHER_STAR) return;
        int index = gridIndexForSlot(event.getRawSlot());
        if (index < 0) return;
        int dx = REL[index][0];
        int dz = REL[index][1];
        if (dx == 0 && dz == 0) return;
        ChunkKey chunkKey = claim.chunkAt(dx, dz);
        if (current.getType() == Material.GREEN_WOOL) {
            plugin.sendMessage(player, "chunk-already-owned");
            return;
        }
        if (!claim.isMember(player.getUniqueId())) {
            plugin.sendMessage(player, "not-bunker-member");
            return;
        }
        ChunkClaimManager.BuyResult result = plugin.getClaimManager().buyChunk(player, claim, chunkKey);
        switch (result) {
            case SUCCESS:
                plugin.sendMessage(player, "chunk-bought",
                        mapOf("coords", chunkKey.chunkX() + ", " + chunkKey.chunkZ()));
                buildItems();
                player.updateInventory();
                break;
            case NOT_ENOUGH_RESOURCES:
                plugin.sendMessage(player, "not-enough-resources",
                        mapOf("list", plugin.getClaimManager().formatCost()));
                break;
            case ALREADY_OWNED:
                plugin.sendMessage(player, "chunk-already-owned");
                break;
            case NOT_AUTHORIZED:
                plugin.sendMessage(player, "not-bunker-member");
                break;
            default:
                plugin.sendMessage(player, "default-error");
                break;
        }
    }

    /** Map.of замена для Java 8. */
    static Map mapOf(Object k1, Object v1) {
        java.util.HashMap m = new java.util.HashMap();
        m.put(k1, v1);
        return m;
    }

    static Map mapOf(Object k1, Object v1, Object k2, Object v2) {
        java.util.HashMap m = new java.util.HashMap();
        m.put(k1, v1);
        m.put(k2, v2);
        return m;
    }

    static Map mapOf(Object k1, Object v1, Object k2, Object v2, Object k3, Object v3) {
        java.util.HashMap m = new java.util.HashMap();
        m.put(k1, v1);
        m.put(k2, v2);
        m.put(k3, v3);
        return m;
    }

    static Map mapOf(Object k1, Object v1, Object k2, Object v2, Object k3, Object v3, Object k4, Object v4) {
        java.util.HashMap m = new java.util.HashMap();
        m.put(k1, v1);
        m.put(k2, v2);
        m.put(k3, v3);
        m.put(k4, v4);
        return m;
    }

    private int gridIndexForSlot(int slot) {
        for (int i = 0; i < GRID_SLOTS.length; i++) {
            if (GRID_SLOTS[i] == slot) return i;
        }
        return -1;
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private String nameOf(UUID uuid) {
        Player player = Bukkit.getPlayer(uuid);
        return player == null ? uuid.toString().substring(0, 8) : player.getName();
    }

    private String namesOf(List uuids) {
        List names = new ArrayList();
        Iterator it = uuids.iterator();
        while (it.hasNext()) names.add(nameOf((UUID) it.next()));
        return String.join(", ", names);
    }

    private String namesOf(Set uuids) {
        List names = new ArrayList();
        Iterator it = uuids.iterator();
        while (it.hasNext()) names.add(nameOf((UUID) it.next()));
        return String.join(", ", names);
    }
}

package ru.yourname.bunker;

import java.util.Collections;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

/** /controlpanel — меню покупки чанков. */
public final class ControlPanelCommand implements CommandExecutor, TabCompleter {

    private final BunkerPlugin plugin;

    public ControlPanelCommand(BunkerPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            plugin.sendMessage(sender, "only-player");
            return true;
        }
        Player player = (Player) sender;
        if (!player.hasPermission("bunker.controlpanel")) {
            plugin.sendMessage(player, "no-permission");
            return true;
        }
        BunkerClaim claim = plugin.getClaimManager().ensureClaimForPlayerGrid(player, player.getLocation());
        if (claim == null) {
            plugin.sendMessage(player, "controlpanel-not-near");
            return true;
        }
        ControlPanelMenu.open(plugin, player, claim);
        return true;
    }

    @Override
    public List onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return Collections.emptyList();
    }
}

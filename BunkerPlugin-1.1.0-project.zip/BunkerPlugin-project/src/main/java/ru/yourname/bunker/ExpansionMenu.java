package ru.yourname.bunker;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/** GUI выбора типа расширения (после клика по маркеру на стене). */
public final class ExpansionMenu implements InventoryHolder {

    private final BunkerPlugin plugin;
    private final Player player;
    private final ProtectedBunker bunker;
    private final BunkerClaim claim;
    private final Location anchor;
    private final ExpansionManager.Direction direction;
    private final List builds;
    private final Inventory inventory;

    public ExpansionMenu(BunkerPlugin plugin, Player player, ProtectedBunker bunker, BunkerClaim claim,
                         Location anchor, ExpansionManager.Direction direction, List builds) {
        this.plugin = plugin;
        this.player = player;
        this.bunker = bunker;
        this.claim = claim;
        this.anchor = anchor.clone();
        this.direction = direction;
        this.builds = builds;
        this.inventory = Bukkit.createInventory(this, 9, color("&6&lРасширение бункера"));
        buildItems();
    }

    public static void open(BunkerPlugin plugin, Player player, ProtectedBunker bunker, BunkerClaim claim,
                            Location anchor, ExpansionManager.Direction direction, List builds) {
        player.openInventory(new ExpansionMenu(plugin, player, bunker, claim, anchor, direction, builds).getInventory());
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    private void buildItems() {
        inventory.setItem(4, item(Material.NETHER_STAR, "&eВыберите тип расширения",
                new String[]{"&7Направление: &f" + direction.display(), "&7Стройка только на купленных чанках."}));
        for (int i = 0; i < builds.size() && i < 8; i++) {
            int slot = i >= 4 ? i + 1 : i; // слот 4 занят звездой
            ExpansionManager.ExpansionBuild build = (ExpansionManager.ExpansionBuild) builds.get(i);
            inventory.setItem(slot, item(build.material(), build.name(), new String[]{
                    build.description(),
                    "&b" + build.width() + "x" + build.height() + " x " + build.length() + " блоков",
                    "&7Ширина: &f" + build.width(),
                    "&7Высота: &f" + build.height(),
                    "&7Клик — построить " + build.name()}));
        }
    }

    public void onClick(InventoryClickEvent event) {
        event.setCancelled(true);
        if (event.getWhoClicked() != player) return;
        ItemStack current = event.getCurrentItem();
        if (current == null || current.getType() == Material.AIR) return;
        int slot = event.getRawSlot();
        if (slot >= 4) slot = slot <= 5 ? -1 : slot - 1; // компенсация звёзды в центре
        if (slot >= 0 && slot < builds.size()) {
            ExpansionManager.ExpansionBuild build = (ExpansionManager.ExpansionBuild) builds.get(slot);
            plugin.getExpansionManager().expand(player, bunker, claim, direction, build);
            player.closeInventory();
        }
    }

    private ItemStack item(Material material, String name, String[] lore) {
        if (material == null) material = Material.GREEN_WOOL;
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(color(name));
        List colored = new ArrayList();
        for (int i = 0; i < lore.length; i++) colored.add(color(lore[i]));
        meta.setLore(colored);
        item.setItemMeta(meta);
        return item;
    }

    private String color(String s) {
        return s == null ? "" : ChatColor.translateAlternateColorCodes('&', s);
    }
}

package ru.yourname.zombies;

import java.util.UUID;
import org.bukkit.Location;

/** "Мозг" одного зомби: конечный автомат + маршрутные точки. */
public final class ZombieBrain {

    /** Состояния автомата. */
    public enum State { IDLE, WANDER, INVESTIGATE, CHASE, SEARCH, RETREAT }

    private final UUID zombieId;
    private State state = State.IDLE;
    private UUID targetPlayerId;
    private Location lastSeenLocation;
    private long lastSeenTick;
    private Location investigateLocation;
    private long investigateUntilTick;
    private Location searchLocation;
    private long searchUntilTick;
    private int lostTicks;
    private Location wanderTarget;
    private int wanderCooldownTicks;
    private Location retreatOrigin;
    private long retreatUntilTick;

    public ZombieBrain(UUID zombieId) {
        this.zombieId = zombieId;
    }

    public UUID zombieId() { return zombieId; }
    public State state() { return state; }
    public void state(State state) { this.state = state; }
    public boolean hasTarget() { return targetPlayerId != null; }
    public UUID targetPlayerId() { return targetPlayerId; }
    public void targetPlayerId(UUID uuid) { this.targetPlayerId = uuid; }
    public Location lastSeenLocation() { return lastSeenLocation; }
    public long lastSeenTick() { return lastSeenTick; }
    public void lastSeenLocation(Location location, long tick) {
        this.lastSeenLocation = location != null ? location.clone() : null;
        this.lastSeenTick = tick;
    }
    public Location investigateLocation() { return investigateLocation; }
    public void investigateLocation(Location location) { this.investigateLocation = location; }
    public long investigateUntilTick() { return investigateUntilTick; }
    public void investigateUntilTick(long tick) { this.investigateUntilTick = tick; }
    public Location searchLocation() { return searchLocation; }
    public void searchLocation(Location location) { this.searchLocation = location; }
    public long searchUntilTick() { return searchUntilTick; }
    public void searchUntilTick(long tick) { this.searchUntilTick = tick; }
    public int lostTicks() { return lostTicks; }
    public void lostTicks(int ticks) { this.lostTicks = ticks; }
    public Location wanderTarget() { return wanderTarget; }
    public void wanderTarget(Location location) { this.wanderTarget = location; }
    public int wanderCooldownTicks() { return wanderCooldownTicks; }
    public void wanderCooldownTicks(int ticks) { this.wanderCooldownTicks = ticks; }
    public Location retreatOrigin() { return retreatOrigin; }
    public void retreatOrigin(Location location) { this.retreatOrigin = location; }
    public long retreatUntilTick() { return retreatUntilTick; }
    public void retreatUntilTick(long tick) { this.retreatUntilTick = tick; }

    /** Сбросить маршруты (при новой цели/состоянии). */
    public void resetRouting() {
        investigateLocation = null;
        investigateUntilTick = 0;
        searchLocation = null;
        searchUntilTick = 0;
        wanderTarget = null;
        wanderCooldownTicks = 0;
        lostTicks = 0;
    }

    public void clearTarget() {
        targetPlayerId = null;
        lastSeenLocation = null;
        lostTicks = 0;
    }
}

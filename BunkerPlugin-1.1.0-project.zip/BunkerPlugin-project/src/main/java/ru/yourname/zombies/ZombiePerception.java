package ru.yourname.zombies;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.util.Vector;

/** Сенсоры зомби: зрение, слух, запах. */
final class ZombiePerception {

    private ZombiePerception() {
    }

    /** Видит ли зомби игрока: радиус, конус FOV, прямая видимость. */
    public static boolean canSee(Zombie zombie, Player player, ZombieConfig config) {
        if (zombie == null || player == null || !player.isOnline() || !zombie.isValid()) return false;
        if (!sameWorld(zombie.getLocation(), player.getLocation())) return false;
        if (zombie.getLocation().distance(player.getLocation()) > config.visionRadius()) return false;
        if (config.visionFovDegrees() < 360.0) {
            Vector toPlayer = player.getEyeLocation().toVector().subtract(zombie.getEyeLocation().toVector());
            if (toPlayer.lengthSquared() < 0.0001) return true;
            if (zombie.getLocation().getDirection().dot(toPlayer.clone().normalize())
                    < Math.cos(Math.toRadians(config.visionFovDegrees() * 0.5))) {
                return false;
            }
        }
        if (!config.visionRequiresLineOfSight()) return true;
        return zombie.hasLineOfSight(player);
    }

    /** Слышит ли зомби игрока (радиус зависит от движения; стены гасят радиус). */
    public static boolean canHear(Zombie zombie, Player player, PlayerStealth stealth, ZombieConfig config) {
        if (zombie == null || player == null || stealth == null) return false;
        if (!sameWorld(zombie.getLocation(), player.getLocation())) return false;
        double radius = hearingRadius(player, stealth, config);
        if (radius <= 0.0) return false;
        double distance = zombie.getLocation().distance(player.getLocation());
        if (distance > radius) return false;
        if (!zombie.hasLineOfSight(player)) {
            boolean throughWalls = config.hearingThroughWalls();
            if (!throughWalls || config.hearingWallPenalty() <= 0.0) return false;
            if (distance > radius * config.hearingWallPenalty()) return false;
        }
        return true;
    }

    /** Чует ли игрока (сквозь стены). */
    public static boolean canSmell(Zombie zombie, Player player, ZombieConfig config) {
        if (zombie == null || player == null) return false;
        if (!sameWorld(zombie.getLocation(), player.getLocation())) return false;
        double radius = config.smellRadius();
        return radius > 0.0 && zombie.getLocation().distanceSquared(player.getLocation()) <= radius * radius;
    }

    /** Радиус слуха: крадётся 5 / идёт 12 / бежит 22; стоит на месте — 0. */
    public static double hearingRadius(Player player, PlayerStealth stealth, ZombieConfig config) {
        if (player == null || stealth == null) return 0.0;
        double moved = stealth.movedDistance();
        if (player.isSneaking()) return moved > 0.06 ? config.hearingSneakRadius() : 0.0;
        if (!player.isSprinting()) return moved > 0.06 ? config.hearingWalkRadius() : 0.0;
        return moved > 0.08 ? config.hearingSprintRadius() : 0.0;
    }

    /** Видна ли точка игроку (rayTrace) — для спавна вне поля зрения. */
    public static boolean locationVisible(Player player, Location target, double maxDistance) {
        if (player == null || target == null || !sameWorld(player.getLocation(), target)) return true;
        Location eyes = player.getEyeLocation();
        Vector direction = target.toVector().subtract(eyes.toVector());
        double length = direction.length();
        if (length < 0.001) return true;
        if (length > maxDistance) return false;
        if (eyes.getDirection().dot(direction.clone().normalize()) <= 0.0) return false;
        return player.getWorld().rayTraceBlocks(eyes, direction.clone().normalize(), length) == null;
    }

    private static boolean sameWorld(Location a, Location b) {
        return a != null && b != null && a.getWorld() != null && a.getWorld().equals(b.getWorld());
    }
}

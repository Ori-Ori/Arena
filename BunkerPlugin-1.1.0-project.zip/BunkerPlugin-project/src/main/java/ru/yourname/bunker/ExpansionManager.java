package ru.yourname.bunker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

/**
 * Расширение бункера: при предмете-активаторе в руке на 4 стенах появляются маркеры,
 * клик по маркеру открывает меню комнат; комната пристраивается за стену.
 */
public final class ExpansionManager implements Listener {

    /** Направление расширения. */
    public enum Direction {
        NORTH("Север", BlockFace.NORTH),
        SOUTH("Юг", BlockFace.SOUTH),
        EAST("Восток", BlockFace.EAST),
        WEST("Запад", BlockFace.WEST);

        private final String display;
        private final BlockFace face;
        Direction(String display, BlockFace face) { this.display = display; this.face = face; }
        public BlockFace face() { return face; }
        public String display() { return display; }
    }

    /** AABB-регион. */
    static final class Region {
        final int minX, minY, minZ, maxX, maxY, maxZ;
        Region(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
            this.minX = minX; this.minY = minY; this.minZ = minZ;
            this.maxX = maxX; this.maxY = maxY; this.maxZ = maxZ;
        }
    }

    /** Описание комнаты расширения из конфига. */
    public static final class ExpansionBuild {
        private final String id, name, description;
        private final Material material;
        private final int width, height, length;
        public ExpansionBuild(String id, String name, String description, Material material,
                              int width, int height, int length) {
            this.id = id; this.name = name; this.description = description; this.material = material;
            this.width = width; this.height = height; this.length = length;
        }
        public String id() { return id; }
        public String name() { return name; }
        public String description() { return description; }
        public Material material() { return material; }
        public int width() { return width; }
        public int height() { return height; }
        public int length() { return length; }
    }

    /** Активный маркер на стене + его оригинальный BlockData (для восстановления). */
    private static final class ActiveMarker {
        private final String bunkerId;
        private final String originalData;
        ActiveMarker(String bunkerId, String originalData) {
            this.bunkerId = bunkerId;
            this.originalData = originalData;
        }
        public String bunkerId() { return bunkerId; }
        public String originalData() { return originalData; }
    }

    private final BunkerPlugin plugin;
    private final Map markersByCoord = new HashMap();   // Map<Long packedPos, ActiveMarker>
    private final Map directionByCoord = new HashMap(); // Map<Long, Direction>
    private final Map holdersByBunker = new HashMap();  // Map<String bunkerId, Set<UUID>>
    private final Map bunkerByPlayer = new HashMap();   // Map<UUID, String bunkerId>
    private BukkitTask task;

    public ExpansionManager(BunkerPlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        if (!plugin.getConfig().getBoolean("expansion.enabled", true)) return;
        stop();
        task = new BukkitRunnable() {
            @Override
            public void run() {
                Iterator it = Bukkit.getOnlinePlayers().iterator();
                while (it.hasNext()) {
                    refresh((Player) it.next());
                }
            }
        }.runTaskTimer(plugin, 10L, 10L);
    }

    public void stop() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        restoreAll();
        holdersByBunker.clear();
        bunkerByPlayer.clear();
        directionByCoord.clear();
    }

    /** Обновить состояние маркеров для игрока (2 раза в секунду). */
    private void refresh(Player player) {
        String bunkerId = currentBunkerId(player);
        if (bunkerId == null) {
            deactivate(player);
            return;
        }
        String active = (String) bunkerByPlayer.get(player.getUniqueId());
        if (active != null && active.equals(bunkerId)) return;
        deactivate(player);
        activate(player, bunkerId);
    }

    /** Ближайший к игроку бункер, которым он может управлять (маркер в радиусе show-radius). */
    private String currentBunkerId(Player player) {
        if (player.getInventory().getItemInMainHand().getType() != heldItem()) return null;
        double radius = configInt("expansion.show-radius", 64);
        double radiusSq = radius * radius;
        String best = null;
        double bestDist = Double.MAX_VALUE;
        Iterator it = plugin.getClaimManager().getClaims().iterator();
        while (it.hasNext()) {
            BunkerClaim claim = (BunkerClaim) it.next();
            if (!claim.canManage(player.getUniqueId())) continue;
            ProtectedBunker bunker = plugin.getBunkerManager().getBunkerById(claim.bunkerId().toString());
            if (bunker == null) continue;
            Iterator markers = markerLocations(bunker).iterator();
            while (markers.hasNext()) {
                double dist = ((Location) markers.next()).distanceSquared(player.getLocation());
                if (dist <= radiusSq && dist < bestDist) {
                    bestDist = dist;
                    best = bunker.id();
                }
            }
        }
        return best;
    }

    /** Показать маркеры на стенах бункера (сохранив оригинальные блоки). */
    private void activate(Player player, String bunkerId) {
        ProtectedBunker bunker = plugin.getBunkerManager().getBunkerById(bunkerId);
        if (bunker == null) return;
        Set holders = (Set) holdersByBunker.get(bunkerId);
        if (holders == null) {
            holders = new HashSet();
            holdersByBunker.put(bunkerId, holders);
        }
        holders.add(player.getUniqueId());
        bunkerByPlayer.put(player.getUniqueId(), bunkerId);
        World world = Bukkit.getWorld(bunker.worldName());
        if (world == null) return;
        Direction[] directions = Direction.values();
        for (int i = 0; i < directions.length; i++) {
            Location loc = markerLocation(bunker, directions[i]);
            if (loc == null) continue;
            Block block = world.getBlockAt(loc);
            long key = key(block);
            if (markersByCoord.containsKey(Long.valueOf(key))) continue;
            String originalData = block.getBlockData().getAsString();
            block.setType(markerMaterial());
            markersByCoord.put(Long.valueOf(key), new ActiveMarker(bunkerId, originalData));
            directionByCoord.put(Long.valueOf(key), directions[i]);
        }
    }

    private void deactivate(Player player) {
        String bunkerId = (String) bunkerByPlayer.remove(player.getUniqueId());
        if (bunkerId == null) {
            bunkerId = holderBunkerId(player.getUniqueId());
            if (bunkerId == null) return;
        }
        Set holders = (Set) holdersByBunker.get(bunkerId);
        if (holders != null) {
            holders.remove(player.getUniqueId());
            if (!holders.isEmpty()) return;
            holdersByBunker.remove(bunkerId);
        }
        restoreBunker(bunkerId);
    }

    private String holderBunkerId(UUID uuid) {
        Iterator it = holdersByBunker.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            if (((Set) entry.getValue()).contains(uuid)) return (String) entry.getKey();
        }
        return null;
    }

    private void restoreBunker(String bunkerId) {
        List toRemove = new ArrayList();
        Iterator it = markersByCoord.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            if (((ActiveMarker) entry.getValue()).bunkerId().equals(bunkerId)) {
                restoreMarker(((Long) entry.getKey()).longValue(), (ActiveMarker) entry.getValue());
                toRemove.add(entry.getKey());
            }
        }
        Iterator removeIt = toRemove.iterator();
        while (removeIt.hasNext()) {
            Object key = removeIt.next();
            markersByCoord.remove(key);
            directionByCoord.remove(key);
        }
    }

    private void restoreAll() {
        Iterator it = markersByCoord.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            restoreMarker(((Long) entry.getKey()).longValue(), (ActiveMarker) entry.getValue());
        }
        markersByCoord.clear();
        directionByCoord.clear();
    }

    private void restoreMarker(long packed, ActiveMarker marker) {
        ProtectedBunker bunker = plugin.getBunkerManager().getBunkerById(marker.bunkerId());
        if (bunker == null) return;
        World world = Bukkit.getWorld(bunker.worldName());
        if (world == null) return;
        Location loc = decode(packed, bunker.worldName());
        if (loc == null) return;
        Block block = world.getBlockAt(loc);
        if (block.getType() != markerMaterial()) return;
        try {
            block.setBlockData(Bukkit.createBlockData(marker.originalData()));
        } catch (IllegalArgumentException e) {
            block.setType(Material.STONE);
        }
    }

    /** Клик по маркеру -> меню выбора комнаты. */
    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block block = event.getClickedBlock();
        if (block == null || event.getHand() != EquipmentSlot.HAND) return;
        long key = key(block);
        ActiveMarker marker = (ActiveMarker) markersByCoord.get(Long.valueOf(key));
        if (marker == null) return;
        Direction direction = (Direction) directionByCoord.get(Long.valueOf(key));
        if (direction == null) return;
        Player player = event.getPlayer();
        if (player.getInventory().getItemInMainHand().getType() != heldItem()) return;
        if (!bunkerByPlayer.containsKey(player.getUniqueId())) return;
        ProtectedBunker bunker = plugin.getBunkerManager().getBunkerById(marker.bunkerId());
        if (bunker == null) return;
        BunkerClaim claim = claimForBunkerAndManager(bunker.id(), player);
        if (claim == null) return;
        event.setCancelled(true);
        Location anchor = new Location(block.getWorld(), block.getX(), block.getY(), block.getZ());
        ExpansionMenu.open(plugin, player, bunker, claim, anchor, direction, builds());
    }

    /** Маркер нельзя сломать. */
    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        if (markersByCoord.containsKey(Long.valueOf(key(event.getBlock())))) {
            event.setCancelled(true);
            plugin.sendMessage(event.getPlayer(), "expansion-marker-protected");
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        deactivate(event.getPlayer());
    }

    /** Построить комнату expansion в направлении direction. */
    public void expand(Player player, ProtectedBunker bunker, BunkerClaim claim,
                       Direction direction, ExpansionBuild build) {
        int width = Math.max(1, build.width());
        int height = Math.max(1, build.height());
        int length = Math.max(1, build.length());

        Region region = regionFor(bunker, direction, width, height, length);
        if (region == null) {
            plugin.sendMessage(player, "default-error");
            return;
        }
        if (!withinOwnedChunks(claim, region)) {
            plugin.sendMessage(player, "expansion-outside-claims");
            return;
        }
        World world = Bukkit.getWorld(bunker.worldName());
        if (world == null) {
            plugin.sendMessage(player, "default-error");
            return;
        }

        Material material = build.material() != null ? build.material() : this.material();
        for (int x = region.minX; x <= region.maxX; x++) {
            for (int y = region.minY; y <= region.maxY; y++) {
                for (int z = region.minZ; z <= region.maxZ; z++) {
                    boolean onShell = x == region.minX || x == region.maxX
                            || y == region.minY || y == region.maxY
                            || z == region.minZ || z == region.maxZ;
                    // стена, смежная с бункером — здесь прорезаем проход
                    boolean onDoorWall = (direction == Direction.EAST && x == region.minX)
                            || (direction == Direction.WEST && x == region.maxX)
                            || (direction == Direction.SOUTH && z == region.minZ)
                            || (direction == Direction.NORTH && z == region.maxZ);
                    // конструктив новой комнаты (несущие плоскости), который нельзя превращать в проход
                    boolean structural = isHorizontal(direction)
                            ? (x == region.minX || x == region.maxX || y == region.minY || y == region.maxY)
                            : (z == region.minZ || z == region.maxZ || y == region.minY || y == region.maxY);
                    Block block = world.getBlockAt(x, y, z);
                    if (onDoorWall && !structural) {
                        block.setType(Material.AIR);        // проход
                    } else {
                        block.setType(onShell ? material : Material.AIR);
                    }
                }
            }
        }

        removeOldWall(bunker, direction, region, world);
        ProtectedBunker expanded = expandedBunker(bunker, region);
        plugin.getBunkerManager().replaceBunker(expanded);

        // сбрасываем активные маркеры — стены изменились, координаты пересчитаются на следующем тике
        String bunkerId = bunker.id();
        restoreBunker(bunkerId);
        holdersByBunker.remove(bunkerId);
        Iterator it = new ArrayList(bunkerByPlayer.entrySet()).iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            if (entry.getValue().equals(bunkerId)) bunkerByPlayer.remove(entry.getKey());
        }

        plugin.sendMessage(player, "expansion-built", ControlPanelMenu.mapOf(
                "name", build.name(),
                "direction", direction.display(),
                "length", String.valueOf(length)));
        player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_BEACON_ACTIVATE, 0.9f, 1.2f);
    }

    private static boolean isHorizontal(Direction direction) {
        return direction == Direction.EAST || direction == Direction.WEST;
    }

    /** Снести старую стену бункера в месте прохода. */
    private void removeOldWall(ProtectedBunker bunker, Direction direction, Region region, World world) {
        switch (direction) {
            case WEST:
                for (int y = region.minY; y <= region.maxY; y++)
                    for (int z = region.minZ; z <= region.maxZ; z++)
                        world.getBlockAt(bunker.minX(), y, z).setType(Material.AIR);
                break;
            case EAST:
                for (int y = region.minY; y <= region.maxY; y++)
                    for (int z = region.minZ; z <= region.maxZ; z++)
                        world.getBlockAt(bunker.maxX(), y, z).setType(Material.AIR);
                break;
            case SOUTH:
                for (int x = region.minX; x <= region.maxX; x++)
                    for (int y = region.minY; y <= region.maxY; y++)
                        world.getBlockAt(x, y, bunker.maxZ()).setType(Material.AIR);
                break;
            case NORTH:
                for (int x = region.minX; x <= region.maxX; x++)
                    for (int y = region.minY; y <= region.maxY; y++)
                        world.getBlockAt(x, y, bunker.minZ()).setType(Material.AIR);
                break;
            default:
                break;
        }
    }

    /** Новый бункер с расширенным AABB (кислород и стены сохраняются). */
    private ProtectedBunker expandedBunker(ProtectedBunker bunker, Region region) {
        return new ProtectedBunker(bunker.id(), bunker.worldName(),
                new HashSet(), new HashSet(),
                Math.min(bunker.minX(), region.minX), Math.min(bunker.minY(), region.minY), Math.min(bunker.minZ(), region.minZ),
                Math.max(bunker.maxX(), region.maxX), Math.max(bunker.maxY(), region.maxY), Math.max(bunker.maxZ(), region.maxZ),
                Math.max(1, bunker.wallThickness()), bunker.oxygenY(),
                bunker.oxygenSeconds(), bunker.maxOxygenSeconds());
    }

    /** Все чанки региона должны быть куплены. */
    private boolean withinOwnedChunks(BunkerClaim claim, Region region) {
        if (claim == null) return false;
        for (int cx = Math.floorDiv(region.minX, 16); cx <= Math.floorDiv(region.maxX, 16); cx++) {
            for (int cz = Math.floorDiv(region.minZ, 16); cz <= Math.floorDiv(region.maxZ, 16); cz++) {
                if (!claim.isChunkOwned(new ChunkKey(claim.worldName(), cx, cz))) return false;
            }
        }
        return true;
    }

    /** AABB комнаты за выбранной стеной (с запасом на стены/пол/потолок). */
    private Region regionFor(ProtectedBunker bunker, Direction direction, int width, int height, int length) {
        int centerX = (bunker.minX() + bunker.maxX()) / 2;
        int centerZ = (bunker.minZ() + bunker.maxZ()) / 2;
        int minY = (bunker.minY() + bunker.maxY()) / 2 - height / 2;
        int maxY = minY + height - 1;
        int floorY = minY - 1;
        int ceilY = maxY + 1;
        int minSide = centerZ - width / 2;
        int maxSide = minSide + width - 1;
        int beforeSide = minSide - 1;
        int afterSide = maxSide + 1;
        int minLen, maxLen;
        switch (direction) {
            case WEST:
                minLen = bunker.minX() - length - 1;
                maxLen = bunker.minX() - 1;
                break;
            case EAST:
                minLen = bunker.maxX() + 1;
                maxLen = bunker.maxX() + length + 1;
                break;
            case SOUTH:
                minLen = centerX - width / 2 - 1;
                maxLen = centerX - width / 2 + width;
                beforeSide = bunker.maxZ() + 1;
                afterSide = bunker.maxZ() + length + 1;
                break;
            case NORTH:
                minLen = centerX - width / 2 - 1;
                maxLen = centerX - width / 2 + width;
                afterSide = bunker.minZ() - 1;
                beforeSide = bunker.minZ() - length - 1;
                break;
            default:
                return null;
        }
        return new Region(minLen, floorY, beforeSide, maxLen, ceilY, afterSide);
    }

    /** Точки размещения маркеров: центр каждой стены. */
    private List markerLocations(ProtectedBunker bunker) {
        List out = new ArrayList();
        if (Bukkit.getWorld(bunker.worldName()) == null) return out;
        Direction[] directions = Direction.values();
        for (int i = 0; i < directions.length; i++) {
            Location loc = markerLocation(bunker, directions[i]);
            if (loc != null) out.add(loc);
        }
        return out;
    }

    private Location markerLocation(ProtectedBunker bunker, Direction direction) {
        World world = Bukkit.getWorld(bunker.worldName());
        if (world == null) return null;
        int midX = (bunker.minX() + bunker.maxX()) / 2;
        int midZ = (bunker.minZ() + bunker.maxZ()) / 2;
        int midY = (bunker.minY() + bunker.maxY()) / 2;
        switch (direction) {
            case WEST: return new Location(world, bunker.minX(), midY, midZ);
            case EAST: return new Location(world, bunker.maxX(), midY, midZ);
            case SOUTH: return new Location(world, midX, midY, bunker.maxZ());
            case NORTH: return new Location(world, midX, midY, bunker.minZ());
            default: return null;
        }
    }

    private long key(Block block) {
        return ProtectedBunker.encode(block.getX(), block.getY(), block.getZ());
    }

    private Location decode(long packed, String worldName) {
        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;
        int x = (int) (packed >> 38);
        if (x >= 33554432) x -= 67108864;
        int y = (int) (packed & 4095L);
        if (y >= 2048) y -= 4096;
        int z = (int) ((packed >> 12) & 67108863L);
        if (z >= 33554432) z -= 67108864;
        return new Location(world, x, y, z);
    }

    /** Список комнат из expansion.builds (+ дефолтная "Комната"). */
    public List builds() {
        List out = new ArrayList();
        Iterator it = plugin.getConfig().getMapList("expansion.builds").iterator();
        while (it.hasNext()) {
            Map raw = (Map) it.next();
            out.add(new ExpansionBuild(
                    stringOf(raw.get("id"), null),
                    stringOf(raw.get("name"), "Расширение"),
                    stringOf(raw.get("description"), ""),
                    parseMaterial(raw.get("material"), material()),
                    intOf(raw.get("width"), configInt("expansion.width-blocks", 3)),
                    intOf(raw.get("height"), configInt("expansion.height-blocks", 3)),
                    intOf(raw.get("length"), configInt("expansion.length-blocks", 5))));
        }
        if (out.isEmpty()) {
            out.add(new ExpansionBuild("room", "Комната", "", material(),
                    configInt("expansion.width-blocks", 3),
                    configInt("expansion.height-blocks", 3),
                    configInt("expansion.length-blocks", 5)));
        }
        return out;
    }

    private Material heldItem() {
        return parseMaterial(plugin.getConfig().getString("expansion.held-item", "PAPER"), Material.PAPER);
    }

    private Material markerMaterial() {
        return parseMaterial(plugin.getConfig().getString("expansion.marker-material", "MOSS_BLOCK"), Material.MOSS_BLOCK);
    }

    private Material material() {
        return parseMaterial(plugin.getConfig().getString("expansion.material", "DEEPSLATE"), Material.DEEPSLATE);
    }

    private BunkerClaim claimForBunkerAndManager(String bunkerId, Player player) {
        Iterator it = plugin.getClaimManager().getClaims().iterator();
        while (it.hasNext()) {
            BunkerClaim claim = (BunkerClaim) it.next();
            if (claim.bunkerId().toString().equals(bunkerId) && claim.canManage(player.getUniqueId())) return claim;
        }
        return null;
    }

    private int configInt(String path, int def) {
        return plugin.getConfig().getInt(path, def);
    }

    private static String stringOf(Object o, String def) {
        return o != null ? String.valueOf(o) : def;
    }

    private static int intOf(Object o, int def) {
        if (o instanceof Number) return ((Number) o).intValue();
        if (o != null) {
            try {
                return Integer.parseInt(String.valueOf(o));
            } catch (NumberFormatException ignored) {
            }
        }
        return def;
    }

    private static Material parseMaterial(Object o, Material def) {
        if (o == null) return def;
        Material material = Material.matchMaterial(String.valueOf(o).toUpperCase(Locale.ROOT));
        return material != null ? material : def;
    }
}

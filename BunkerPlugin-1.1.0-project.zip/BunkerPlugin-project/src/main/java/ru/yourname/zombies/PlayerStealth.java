package ru.yourname.zombies;

import java.util.UUID;
import org.bukkit.Location;

/** Стелс-состояние игрока: newbie-защита, прогресс пряток, кулдаун обнаружения. */
public final class PlayerStealth {

    private final UUID playerId;
    private int newbieProtectionLeft;   // секунд осталось newbie-защиты
    private double movedDistance;       // пройдено за последний тик (для слуха)
    private int hideProgressSeconds;    // прогресс "тишины"
    private boolean hideBarVisible;
    private int escapeCooldownUntilTick;
    private Location lastLocation;

    public PlayerStealth(UUID playerId, int newbieProtectionLeft) {
        this.playerId = playerId;
        this.newbieProtectionLeft = Math.max(0, newbieProtectionLeft);
    }

    public UUID playerId() { return playerId; }
    public int newbieProtectionLeft() { return newbieProtectionLeft; }
    public void newbieProtectionLeft(int seconds) { this.newbieProtectionLeft = Math.max(0, seconds); }
    public double movedDistance() { return movedDistance; }
    public void movedDistance(double distance) { this.movedDistance = distance; }
    public int hideProgressSeconds() { return hideProgressSeconds; }
    public void hideProgressSeconds(int seconds) { this.hideProgressSeconds = seconds; }
    public boolean hideBarVisible() { return hideBarVisible; }
    public void hideBarVisible(boolean visible) { this.hideBarVisible = visible; }
    public int escapeCooldownUntilTick() { return escapeCooldownUntilTick; }
    public void escapeCooldownUntilTick(int tick) { this.escapeCooldownUntilTick = tick; }
    public Location lastLocation() { return lastLocation; }
    public void lastLocation(Location location) { this.lastLocation = location; }
}

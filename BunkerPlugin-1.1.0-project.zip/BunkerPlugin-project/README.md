# BunkerPlugin 1.1.0 (чистая версия)

Плагин Paper/Spigot 1.21: бункеры со строительством по схематикам WorldEdit,
команды (тимы), покупка чанков 3×3, кислород, расширение бункера, умные зомби
(слух/зрение/запах, стая, прятки), PlaceholderAPI.

## Состав
- `src/main/java/ru/yourname/bunker/` — 14 классов ядра
- `src/main/java/ru/yourname/zombies/` — 7 классов ИИ зомби
- `src/main/resources/` — plugin.yml, config.yml, messages.yml, materials.yml, zombies.yml
- `BunkerPlugin-1.1.0-clean.jar` — собранный артефакт (40 классов + ресурсы)

## Точка старта строительства (config.yml)
    creation:
      anchor: "SURFACE"     # SURFACE | PLAYER | FIXED
      surface-y-offset: 0   # <0 — зарыть в землю, >0 — поднять
      player-y-offset: 0
      fixed-y: 64

SURFACE — самый высокий блок в центре чанка +1; PLAYER — Y игрока
(+ schematic.paste-y-offset + player-y-offset); FIXED — абсолютная высота.
Вставка центруется по чанку на выбранной высоте.

## Сборка (Maven, стандартный путь)
    mvn package            # paper-api 1.21 + WorldEdit 7 + PlaceholderAPI в pom

Альтернативная сборка использовалась в песочнице: ECJ 4.4, target 1.8,
по сигнатурным стабам реального API (см. отчёт Задача2).

## Команды
/bunker <reload|create|cancel|info|invite|accept|deny|give|deputy>, /controlpanel
Права: bunker.reload (op), bunker.create (true), bunker.controlpanel (true),
bunker.protection.bypass (false), bunker.oxygen.bypass (false),
bunker.zombies.newbie.bypass (op).

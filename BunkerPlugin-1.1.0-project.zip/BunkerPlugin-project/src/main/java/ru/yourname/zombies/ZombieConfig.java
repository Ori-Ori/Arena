package ru.yourname.zombies;

import org.bukkit.configuration.file.FileConfiguration;

/** Обёртка над zombies.yml: все параметры ИИ с дефолтами. */
public final class ZombieConfig {

    private final FileConfiguration config;

    public ZombieConfig(FileConfiguration config) {
        this.config = config;
    }

    public FileConfiguration raw() {
        return config;
    }

    // ---- spawn ----
    public int spawnIntervalSeconds() { return Math.max(1, config.getInt("spawn.attempts-interval-seconds", 5)); }
    public int spawnTriesPerPlayer() { return Math.max(0, config.getInt("spawn.tries-per-player", 4)); }
    public int spawnMinDistance() { return Math.max(1, config.getInt("spawn.min-distance", 50)); }
    public int spawnMaxDistance() { return Math.max(1, config.getInt("spawn.max-distance", 60)); }
    public int spawnPerPlayerLimit() { return Math.max(0, config.getInt("spawn.per-player-limit", 15)); }
    public int spawnGlobalLimit() { return Math.max(0, config.getInt("spawn.global-limit", 200)); }
    public boolean spawnDay() { return config.getBoolean("spawn.day-spawn", true); }
    public boolean spawnOnlySurfacePlayers() { return config.getBoolean("spawn.only-surface-players", true); }
    public boolean spawnAvoidLineOfSight() { return config.getBoolean("spawn.avoid-player-line-of-sight", true); }

    // ---- behavior.vision ----
    public double visionRadius() { return config.getDouble("behavior.vision.radius", 16); }
    public double visionFovDegrees() { return config.getDouble("behavior.vision.fov-degrees", 120); }
    public boolean visionRequiresLineOfSight() { return config.getBoolean("behavior.vision.requires-line-of-sight", true); }
    public boolean visionEnabled() { return config.getBoolean("behavior.vision.enabled", true); }

    // ---- behavior.hearing ----
    public double hearingSneakRadius() { return config.getDouble("behavior.hearing.sneak-radius", 5); }
    public double hearingWalkRadius() { return config.getDouble("behavior.hearing.walk-radius", 12); }
    public double hearingSprintRadius() { return config.getDouble("behavior.hearing.sprint-radius", 22); }
    public double hearingWallPenalty() { return config.getDouble("behavior.hearing.wall-penalty-factor", 0.12); }
    public boolean hearingThroughWalls() { return config.getBoolean("behavior.hearing.allow-through-walls", true); }
    public int hearingImpulseSeconds() { return Math.max(1, config.getInt("behavior.hearing.impulse-interval-seconds", 1)); }

    // ---- behavior.smell ----
    public double smellRadius() { return config.getDouble("behavior.smell.radius", 15); }

    // ---- behavior.alert ----
    public double alertShoutRadius() { return config.getDouble("behavior.alert.shout-radius", 20); }

    // ---- behavior.targeting ----
    public double targetLoseDistance() { return config.getDouble("behavior.targeting.lose-distance", 60.0); }
    public int hiddenProgressSeconds() { return Math.max(1, config.getInt("behavior.targeting.hide-progress-seconds", 20)); }
    public int hiddenProgressBarLength() { return Math.max(4, config.getInt("behavior.targeting.hide-progress-bar-length", 20)); }
    public double hiddenMinDistance() { return config.getDouble("behavior.targeting.lose-min-distance", 8.0); }
    public double hiddenMaxSneakMove() { return config.getDouble("behavior.targeting.lose-max-sneak-move-per-second", 0.03); }
    public int hiddenProgressResetPerSecond() { return Math.max(1, config.getInt("behavior.targeting.lose-progress-reset-per-second", 2)); }
    public boolean hiddenRequiresNoLineOfSight() { return config.getBoolean("behavior.targeting.lose-requires-no-line-of-sight", true); }
    public boolean hiddenRequiresAllNoLineOfSight() { return config.getBoolean("behavior.targeting.hide-requires-all-zombies-no-line-of-sight", true); }
    public int escapeCooldownSeconds() { return Math.max(0, config.getInt("behavior.targeting.escape-cooldown-seconds", 6)); }
    public double retreatDistance() { return config.getDouble("behavior.targeting.retreat-distance-on-lose", 25.0); }
    public double retreatSpeed() { return config.getDouble("behavior.targeting.retreat-speed", 0.55); }
    public int retreatMaxSeconds() { return Math.max(1, config.getInt("behavior.targeting.retreat-max-seconds", 20)); }
    public int searchLastSeenSeconds() { return Math.max(1, config.getInt("behavior.targeting.search-last-seen-seconds", 8)); }

    // ---- behavior.investigate ----
    public boolean investigateEnabled() { return config.getBoolean("behavior.investigate.enabled", true); }
    public int investigateRadius() { return Math.max(1, config.getInt("behavior.investigate.search-radius", 8)); }
    public int investigateMaxSeconds() { return Math.max(1, config.getInt("behavior.investigate.search-seconds", 6)); }
    public double investigateSpeed() { return config.getDouble("behavior.investigate.speed", 0.45); }

    // ---- behavior.wander ----
    public boolean wanderEnabled() { return config.getBoolean("behavior.wander.enabled", true); }
    public int wanderIntervalTicks() { return Math.max(20, config.getInt("behavior.wander.interval-ticks", 100)); }
    public double wanderRadius() { return config.getDouble("behavior.wander.radius", 10); }
    public double wanderSpeed() { return config.getDouble("behavior.wander.speed", 0.32); }

    // ---- behavior.pack ----
    public boolean packEnabled() { return config.getBoolean("behavior.pack.enabled", true); }
    public boolean packChainAlert() { return config.getBoolean("behavior.pack.chain-alert", true); }
    public double packChainRadius() { return config.getDouble("behavior.pack.chain-radius", 24); }
    public int packMaxSize() { return Math.max(1, config.getInt("behavior.pack.max-pack-size", 6)); }

    // ---- newbie ----
    public boolean newbieEnabled() { return config.getBoolean("newbie.enabled", true); }
    public int newbieDurationSeconds() { return Math.max(0, config.getInt("newbie.duration-minutes", 60)) * 60; }
    public int newbieSaveIntervalSeconds() { return Math.max(15, config.getInt("newbie.save-interval-seconds", 60)); }
}

package ru.yourname.bunker;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/** Менеджер клеймов (тим) и покупки чанков. Данные — claims.yml. */
public final class ChunkClaimManager {

    /** Результат покупки чанка. */
    public enum BuyResult { SUCCESS, INVALID_CHUNK, NOT_AUTHORIZED, ALREADY_OWNED, NOT_ENOUGH_RESOURCES }

    private final BunkerPlugin plugin;
    private final Map claims = new LinkedHashMap();       // Map<UUID bunkerId, BunkerClaim>
    private final Map chunkToClaim = new LinkedHashMap(); // Map<ChunkKey, UUID bunkerId>
    private File file;
    private FileConfiguration config;

    public ChunkClaimManager(BunkerPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        if (!plugin.getDataFolder().exists() && !plugin.getDataFolder().mkdirs()) {
            plugin.getLogger().warning("Could not create plugin data folder");
        }
        file = new File(plugin.getDataFolder(), "claims.yml");
        if (!file.exists()) {
            plugin.saveResource("claims.yml", false);
        }
        config = YamlConfiguration.loadConfiguration(file);
        claims.clear();
        chunkToClaim.clear();
        ConfigurationSection section = config.getConfigurationSection("claims");
        if (section == null) return;
        Iterator it = section.getKeys(false).iterator();
        while (it.hasNext()) {
            String key = (String) it.next();
            UUID bunkerId;
            try {
                bunkerId = UUID.fromString(key);
            } catch (IllegalArgumentException e) {
                continue;
            }
            String base = "claims." + key + ".";
            String world = config.getString(base + "world", "");
            int centerX = config.getInt(base + "center-x", 0);
            int centerZ = config.getInt(base + "center-z", 0);
            UUID owner;
            try {
                owner = UUID.fromString(config.getString(base + "owner", ""));
            } catch (IllegalArgumentException e) {
                continue;
            }
            final BunkerClaim claim = new BunkerClaim(bunkerId, world, centerX, centerZ, owner);
            forEachUuid(config.getStringList(base + "deputies"), uuid -> claim.addDeputy(uuid));
            forEachUuid(config.getStringList(base + "members"), uuid -> claim.addMember(uuid));
            Iterator owned = config.getStringList(base + "owned").iterator();
            while (owned.hasNext()) {
                ChunkKey chunkKey = ChunkKey.fromDataString(world, (String) owned.next());
                if (chunkKey != null) {
                    claim.addOwnedChunk(chunkKey);
                    chunkToClaim.put(chunkKey, bunkerId);
                }
            }
            forEachUuid(config.getStringList(base + "invites"), uuid -> claim.invite(uuid));
            forEachUuid(config.getStringList(base + "requests"), uuid -> claim.requestJoin(uuid));
            claims.put(bunkerId, claim);
        }
    }

    private interface UuidConsumer { void accept(UUID uuid); }

    private static void forEachUuid(List strings, UuidConsumer consumer) {
        Iterator it = strings.iterator();
        while (it.hasNext()) {
            Optional uuid = parseUuid((String) it.next());
            if (uuid.isPresent()) consumer.accept((UUID) uuid.get());
        }
    }

    public void save() {
        if (config == null || file == null) return;
        config.set("claims", null);
        Iterator it = claims.values().iterator();
        while (it.hasNext()) {
            BunkerClaim claim = (BunkerClaim) it.next();
            String base = "claims." + claim.bunkerId().toString() + ".";
            config.set(base + "world", claim.worldName());
            config.set(base + "center-x", Integer.valueOf(claim.centerChunkX()));
            config.set(base + "center-z", Integer.valueOf(claim.centerChunkZ()));
            config.set(base + "owner", claim.owner().toString());
            config.set(base + "deputies", uuidStrings(claim.deputies()));
            config.set(base + "members", uuidStrings(claim.members()));
            config.set(base + "owned", chunkStrings(claim.ownedChunks()));
            config.set(base + "invites", uuidStrings(mapInvites(claim.invites())));
            config.set(base + "requests", uuidStrings(mapRequests(claim.requests())));
        }
        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save claims.yml: " + e.getMessage());
        }
    }

    private static List mapInvites(List invites) {
        List out = new ArrayList();
        Iterator it = invites.iterator();
        while (it.hasNext()) out.add(((BunkerClaim.Invite) it.next()).targetId());
        return out;
    }

    private static List mapRequests(List requests) {
        List out = new ArrayList();
        Iterator it = requests.iterator();
        while (it.hasNext()) out.add(((BunkerClaim.JoinRequest) it.next()).playerId());
        return out;
    }

    public BunkerClaim createClaim(UUID bunkerId, String worldName, int centerChunkX, int centerChunkZ, UUID owner) {
        BunkerClaim claim = new BunkerClaim(bunkerId, worldName, centerChunkX, centerChunkZ, owner);
        claims.put(bunkerId, claim);
        chunkToClaim.put(new ChunkKey(worldName, centerChunkX, centerChunkZ), bunkerId);
        save();
        return claim;
    }

    public BunkerClaim getClaim(UUID bunkerId) { return (BunkerClaim) claims.get(bunkerId); }

    public Collection getClaims() { return new ArrayList(claims.values()); }

    /** Клейм, чья сетка 3x3 содержит данную точку. */
    public BunkerClaim findClaimForPlayerGrid(Location loc) {
        if (loc == null || loc.getWorld() == null) return null;
        int chunkX = loc.getBlockX() >> 4;
        int chunkZ = loc.getBlockZ() >> 4;
        Iterator it = claims.values().iterator();
        while (it.hasNext()) {
            BunkerClaim claim = (BunkerClaim) it.next();
            if (claim.worldName().equalsIgnoreCase(loc.getWorld().getName())
                    && Math.abs(chunkX - claim.centerChunkX()) <= 1
                    && Math.abs(chunkZ - claim.centerChunkZ()) <= 1) {
                return claim;
            }
        }
        return null;
    }

    public BunkerClaim findClaimWhereCanManage(Player player) {
        UUID uuid = player.getUniqueId();
        Iterator it = claims.values().iterator();
        while (it.hasNext()) {
            BunkerClaim claim = (BunkerClaim) it.next();
            if (claim.canManage(uuid)) return claim;
        }
        return null;
    }

    public BunkerClaim findClaimWhereLeader(Player player) {
        Iterator it = claims.values().iterator();
        while (it.hasNext()) {
            BunkerClaim claim = (BunkerClaim) it.next();
            if (claim.isLeader(player.getUniqueId())) return claim;
        }
        return null;
    }

    public BunkerClaim findClaimWhereMember(Player player) {
        return player != null ? findClaimWhereMember(player.getUniqueId()) : null;
    }

    public BunkerClaim findClaimWhereMember(UUID uuid) {
        Iterator it = claims.values().iterator();
        while (it.hasNext()) {
            BunkerClaim claim = (BunkerClaim) it.next();
            if (claim.isMember(uuid)) return claim;
        }
        return null;
    }

    public BunkerClaim findClaimWithInviteFor(UUID uuid) {
        Iterator it = claims.values().iterator();
        while (it.hasNext()) {
            BunkerClaim claim = (BunkerClaim) it.next();
            if (claim.findInvite(uuid).isPresent()) return claim;
        }
        return null;
    }

    public BunkerClaim findClaimWithRequestForManager(Player player) {
        UUID uuid = player.getUniqueId();
        Iterator it = claims.values().iterator();
        while (it.hasNext()) {
            BunkerClaim claim = (BunkerClaim) it.next();
            if (claim.canManage(uuid) && !claim.requests().isEmpty()) return claim;
        }
        return null;
    }

    /** Найти клейм игрока или создать его, если игрок стоит рядом с бункером без клейма (миграция старых данных). */
    public BunkerClaim ensureClaimForPlayerGrid(Player player, Location loc) {
        BunkerClaim existing = findClaimForPlayerGrid(loc);
        if (existing != null) return existing;
        if (player == null || loc == null || loc.getWorld() == null) return null;
        int chunkX = loc.getBlockX() >> 4;
        int chunkZ = loc.getBlockZ() >> 4;
        Iterator it = plugin.getBunkerManager().getBunkers().iterator();
        while (it.hasNext()) {
            ProtectedBunker bunker = (ProtectedBunker) it.next();
            if (!bunker.isSameWorld(loc.getWorld())) continue;
            int bunkerChunkX = Math.floorDiv(bunker.minX(), 16);
            int bunkerChunkZ = Math.floorDiv(bunker.minZ(), 16);
            if (Math.abs(chunkX - bunkerChunkX) <= 1 && Math.abs(chunkZ - bunkerChunkZ) <= 1) {
                UUID bunkerId;
                try {
                    bunkerId = UUID.fromString(bunker.id());
                } catch (IllegalArgumentException e) {
                    continue;
                }
                if (!claims.containsKey(bunkerId)) {
                    return createClaim(bunkerId, bunker.worldName(), bunkerChunkX, bunkerChunkZ, player.getUniqueId());
                }
            }
        }
        return null;
    }

    /** Чанковая защита: блок в купленном чанке, а игрок — не участник тимы. */
    public boolean isProtectedBlockFor(Player player, Block block) {
        if (player == null || block == null) return false;
        if (player.hasPermission("bunker.protection.bypass")) return false;
        BunkerClaim claim = claimForBlock(block);
        return claim != null && !claim.isMember(player.getUniqueId());
    }

    public boolean isClaimedChunkBlock(Block block) {
        return claimForBlock(block) != null;
    }

    private BunkerClaim claimForBlock(Block block) {
        if (block == null || block.getWorld() == null) return null;
        ChunkKey key = new ChunkKey(block.getWorld().getName(), block.getX() >> 4, block.getZ() >> 4);
        UUID bunkerId = (UUID) chunkToClaim.get(key);
        return bunkerId != null ? (BunkerClaim) claims.get(bunkerId) : null;
    }

    /** Цена одного чанка: Map<Material, Integer> из секции cost. */
    public Map getCost() {
        Map out = new LinkedHashMap();
        if (config == null) return out;
        ConfigurationSection section = config.getConfigurationSection("cost");
        if (section == null) return out;
        Iterator it = section.getKeys(false).iterator();
        while (it.hasNext()) {
            String key = (String) it.next();
            Material material = Material.matchMaterial(key.toUpperCase(Locale.ROOT));
            if (material != null) {
                int amount = section.getInt(key, 0);
                if (amount > 0) out.put(material, Integer.valueOf(amount));
            }
        }
        return out;
    }

    /** Покупка чанка: проверки (сетка, права, не куплен, ресурсы) -> списание и сохранение. */
    public BuyResult buyChunk(Player player, BunkerClaim claim, ChunkKey chunkKey) {
        if (player == null || claim == null || chunkKey == null) return BuyResult.INVALID_CHUNK;
        if (!isInsideGrid(claim, chunkKey)) return BuyResult.INVALID_CHUNK;
        if (!claim.isMember(player.getUniqueId())) return BuyResult.NOT_AUTHORIZED;
        if (claim.isChunkOwned(chunkKey)) return BuyResult.ALREADY_OWNED;
        Map cost = getCost();
        if (!getMissingResources(player, cost).isEmpty()) return BuyResult.NOT_ENOUGH_RESOURCES;
        takeResources(player, cost);
        claim.addOwnedChunk(chunkKey);
        chunkToClaim.put(chunkKey, claim.bunkerId());
        save();
        return BuyResult.SUCCESS;
    }

    /** Чанк внутри сетки 3x3 вокруг центра клейма. */
    public boolean isInsideGrid(BunkerClaim claim, ChunkKey chunkKey) {
        if (claim == null || chunkKey == null) return false;
        if (!claim.worldName().equalsIgnoreCase(chunkKey.worldName())) return false;
        int dx = chunkKey.chunkX() - claim.centerChunkX();
        int dz = chunkKey.chunkZ() - claim.centerChunkZ();
        return dx >= -1 && dx <= 1 && dz >= -1 && dz <= 1;
    }

    private Map getMissingResources(Player player, Map cost) {
        Map missing = new LinkedHashMap();
        Iterator it = cost.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            Material material = (Material) entry.getKey();
            int required = ((Integer) entry.getValue()).intValue();
            if (countMaterial(player, material) < required) {
                missing.put(material, Integer.valueOf(required - countMaterial(player, material)));
            }
        }
        return missing;
    }

    private int countMaterial(Player player, Material material) {
        ItemStack[] contents = player.getInventory().getContents();
        int count = 0;
        for (int i = 0; i < contents.length; i++) {
            ItemStack item = contents[i];
            if (item != null && item.getType() == material) count += item.getAmount();
        }
        return count;
    }

    private void takeResources(Player player, Map cost) {
        ItemStack[] contents = player.getInventory().getContents();
        Iterator it = cost.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            Material material = (Material) entry.getKey();
            int remaining = ((Integer) entry.getValue()).intValue();
            for (int i = 0; i < contents.length && remaining > 0; i++) {
                ItemStack item = contents[i];
                if (item != null && item.getType() == material) {
                    int take = Math.min(item.getAmount(), remaining);
                    item.setAmount(item.getAmount() - take);
                    remaining -= take;
                    if (item.getAmount() <= 0) contents[i] = null;
                }
            }
        }
        player.getInventory().setContents(contents);
        player.updateInventory();
    }

    /** "64 камня, 16 железных слитков" — для сообщений. */
    public String formatCost() {
        StringBuilder sb = new StringBuilder();
        Iterator it = getCost().entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            if (sb.length() > 0) sb.append(", ");
            sb.append(((Integer) entry.getValue()).intValue()).append(" ")
              .append(materialDisplayName((Material) entry.getKey()));
        }
        return sb.toString();
    }

    public String formatMissing(Map missing) {
        StringBuilder sb = new StringBuilder();
        Iterator it = missing.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            if (sb.length() > 0) sb.append(", ");
            sb.append(((Integer) entry.getValue()).intValue()).append(" ")
              .append(materialDisplayName((Material) entry.getKey()));
        }
        return sb.toString();
    }

    /** Русское название материала из materials.yml. */
    public String materialDisplayName(Material material) {
        String name = plugin.getMaterials().getString("names." + material.name().toLowerCase(Locale.ROOT));
        if (name != null && !name.trim().isEmpty()) return name;
        if (material == Material.COBBLESTONE) { // совместимость с опечаткой в старых конфигах
            String legacy = plugin.getMaterials().getString("names.cobbestone");
            if (legacy != null && !legacy.trim().isEmpty()) return legacy;
        }
        return material.name().toLowerCase(Locale.ROOT).replace('_', ' ');
    }

    private static Optional parseUuid(String s) {
        if (s == null) return Optional.empty();
        try {
            return Optional.of(UUID.fromString(s.trim()));
        } catch (IllegalArgumentException e) {
            return Optional.empty();
        }
    }

    private static List uuidStrings(Collection uuids) {
        List out = new ArrayList();
        Iterator it = uuids.iterator();
        while (it.hasNext()) out.add(it.next().toString());
        return out;
    }

    private static List chunkStrings(Collection chunks) {
        List out = new ArrayList();
        Iterator it = chunks.iterator();
        while (it.hasNext()) out.add(((ChunkKey) it.next()).toDataString());
        return out;
    }

    public World worldOf(BunkerClaim claim) {
        return org.bukkit.Bukkit.getWorld(claim.worldName());
    }
}
